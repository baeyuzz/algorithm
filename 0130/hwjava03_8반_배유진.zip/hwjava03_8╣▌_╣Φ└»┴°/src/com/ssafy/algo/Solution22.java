package com.ssafy.algo;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class Solution22 {
	public static void main(String[] args) throws FileNotFoundException {
		int t, n, m, x, y, dir;
		boolean v[][];

		System.setIn(new FileInputStream("solution.txt"));

		Scanner sc = new Scanner(System.in);

		t = sc.nextInt();

		for (int test = 0; test < t; test++) {
			n = sc.nextInt();
			m = sc.nextInt();

			int die = m;

			v = new boolean[n][n];

			for (int i = 0; i < m; i++) { // 소금쟁이 수 만큼 돌리기

				x = sc.nextInt();
				y = sc.nextInt();
				dir = sc.nextInt();

				if (v[x][y] == true) { // 첫 시작위치에 소금 쟁이 있으면 죽음
					m--;
					continue; // 다음 소금쟁이
				}

				int tx = x, ty = y;
				int cnt = 0;

				for (int j = 3; j > 0; j--) { // 3,2,1 더하면서 4방향 돌리기

					int dx[] = { 0, -j, j, 0, 0 };
					int dy[] = { 0, 0, 0, -j, j };

					tx += dx[dir];
					ty += dy[dir];

					if (tx < n && tx >= 0 && ty < n && ty >= 0) { // 범위 안 벗어나면
						if (v[tx][ty] == true) { // tx tyㅇㅔ 있으면
							die--;
							break;

						} else { // tx ty 에 아무도 없으면
							cnt++;
						}
					} else { // 범위 벗어나면
						die--;
						break; // 3,2,1 ++ 하는 거 탈출하고 새 소금쟁이
					}
				}
				if (cnt == 3) // 3번 다 뚜ㅣ면.. 마지막 자리에 트루
					v[tx][ty] = true;
			}

			System.out.println(die);
		}
		sc.close();
	}
}
