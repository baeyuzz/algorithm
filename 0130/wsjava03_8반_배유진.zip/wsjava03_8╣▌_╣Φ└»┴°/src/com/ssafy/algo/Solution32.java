package com.ssafy.algo;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class Solution32 {
	public static void main(String[] args) throws FileNotFoundException {
		System.setIn(new FileInputStream("solution.txt"));

		int t, mx, my, n, dir, jump = 0;
		int px[], py[], pn[]; // 참가자
		int trap, tx, ty; // 함정

		int[][] map;
		Scanner sc = new Scanner(System.in);

		t = sc.nextInt();

		for (int test = 0; test < t; test++) {

			mx = sc.nextInt();
			my = sc.nextInt();

			n = sc.nextInt();

			map = new int[mx + 1][my + 1];

			for (int i = 1; i <= mx; i++) { // 맵
				for (int j = 1; j <= my; j++) {
					map[i][j] = sc.nextInt();
				}
			}

			// 참여자
			px = new int[n];
			py = new int[n];
			pn = new int[n];
			int pp[] = new int[n];

			for (int i = 0; i < n; i++) {
				px[i] = sc.nextInt();
				py[i] = sc.nextInt();
				pn[i] = sc.nextInt(); //

			}

			// 참여자 끝

			trap = sc.nextInt(); // 함정 수
			for (int i = 0; i < trap; i++) {
				tx = sc.nextInt();
				ty = sc.nextInt();
				map[tx][ty] = 0;
			}

			// 함정 끝

			// 여기부터 이제 상금~
			int tp = -1000 * n;

			for (int i = 0; i < n; i++) { // 0번 참가자부터

				int x = px[i]; // 지금 사람의 엑스 좌표
				int y = py[i]; // 지금 사람의 와이 좌표

				for (int j = 0; j < pn[i]; j++) { // 참여 횟수 만큼 ..// 한 사람의 기회 pn
					dir = map[x][y] / 10;
					jump = map[x][y] % 10;

					int dx[] = { 0, 0, jump, 0, -jump };
					int dy[] = { 0, jump, 0, -jump, 0 };
//					System.out.println("바꾸기 전 : num-"+(i+1)+" "+ "x : "+x+" y : "+y);
					x += dx[dir];
					y += dy[dir];
//					System.out.println("바꾼 후 : num-"+(i+1)+" "+ "x : "+x+" y : "+y);

					if (x >= 0 && y >= 0 && x <= mx && y <= my) { // 점프 뛴게 범위 내면
						if (map[x][y] == 0) { // 함정에 걸리면 이 사람은 기회 없음.. //System.out.println("trap");
							break;
						}
						if (j == pn[i] - 1) { // 범위 내고 함정에도 안 걸림
							tp += map[x][y] * 100;// 마지막 위치에서 돈 받음 //System.out.println("상금 : "+map[x][y]*100);
						}
					} else { // 범위 밖이면 // System.out.println("out of boundary");
						break;
					}
//					System.out.println();
//					System.out.println(" x : "+x+", y : "+y);
				}
			}
//			System.out.println();
			System.out.println("total : " + tp);
//			System.out.println();
		}
	}
}
