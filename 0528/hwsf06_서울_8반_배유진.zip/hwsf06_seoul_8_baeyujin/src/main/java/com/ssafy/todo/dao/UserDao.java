package com.ssafy.todo.dao;

import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

import com.ssafy.todo.dto.UserInfo;


@Mapper
@Repository
public interface UserDao {

	String login(UserInfo user);
	

}
