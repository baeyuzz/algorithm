package com.ssafy.todo.service;

import com.ssafy.todo.dto.UserInfo;

public interface UserService {
	
	boolean login(UserInfo user); 

}
