package com.ssafy.todo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ssafy.todo.dao.TodoDao;
import com.ssafy.todo.dto.Todo;

@Service
public class TodoServiceImpl implements TodoService {
	
	private TodoDao dao;
	
	@Autowired
	public void setDao(TodoDao dao) {
		this.dao = dao;
	}
	
	public boolean addTodo(Todo todo) {
		return dao.addTodo(todo);
	}

	public boolean modifyTodo(Todo todo) {
		return dao.modifyTodo(todo);
	}

	public boolean removeTodo(int no) {
		return dao.removeTodo(no);
	}

	public List<Todo> findTodoList(String userId) {
		return dao.findTodoList(userId);
	}

	public Todo findTodo(int no) {
		return dao.findTodo(no);
	}

	public boolean removeTodoList(String userId) {
		return dao.removeTodoList(userId);
	}

	public boolean completeTodo(int no) {
		return dao.completeTodo(no);
	}

}
