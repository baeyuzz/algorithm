package com.ssafy.todo.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.ssafy.todo.dto.UserInfo;
import com.ssafy.todo.service.UserService;

@RequestMapping("/user")
@Controller
public class UserController {

	private UserService service;
	
	@Autowired
	public void setService(UserService service) {
		this.service = service;
	}
	
	@PostMapping("/login.do")
	public String login(UserInfo user, HttpSession session, Model model) {
		boolean res = service.login(user);

		if (res) {
			session.setAttribute("id", user.getId());
			model.addAttribute("id", user.getId());
			return "redirect:/list.do";
		} else
			return "redirect:/index.jsp";
	}

	@GetMapping("/logout.do")
	public String logout(HttpSession session) {
		session.invalidate();

		return "redirect:/index.jsp";
	}

}
