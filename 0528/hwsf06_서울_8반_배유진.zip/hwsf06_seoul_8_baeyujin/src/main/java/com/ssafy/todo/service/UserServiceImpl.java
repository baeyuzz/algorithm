package com.ssafy.todo.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ssafy.todo.dao.UserDao;
import com.ssafy.todo.dto.UserInfo;

@Service
public class UserServiceImpl implements UserService {

	private UserDao dao;
	@Autowired
	public void setDao(UserDao dao) {
		this.dao = dao;
	}
	
	@Override
	public boolean login(UserInfo user) {
			return dao.login(user)!=null;
	}

}
