package com.ssafy.todo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Hwsf06Seoul8BaeyujinApplication {

	public static void main(String[] args) {
		SpringApplication.run(Hwsf06Seoul8BaeyujinApplication.class, args);
	}

}
