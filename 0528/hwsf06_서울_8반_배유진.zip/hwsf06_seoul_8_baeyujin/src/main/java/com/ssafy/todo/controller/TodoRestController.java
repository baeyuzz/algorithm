package com.ssafy.todo.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.ssafy.todo.dto.Todo;
import com.ssafy.todo.service.TodoService;

@CrossOrigin(origins = {"*"}, maxAge = 6000)
@RestController
public class TodoRestController {

	private TodoService service;
	@Autowired
	public void setService(TodoService service) {
		this.service = service;
	}
//	
//	boolean removeTodoList(String userId);
	// 도서목록 정보조회 
	
	@GetMapping("/{id}.list")
	public List<Todo> findTodoList(@PathVariable String id) {
		return service.findTodoList(id);
	}
	
	
	@GetMapping("/{no}")
	public Todo findTodo(@PathVariable int no) {
		Todo td = service.findTodo(no);
		return td;
	}
	
	
//	boolean removeTodo(int no);
	@DeleteMapping("/{no}")
	public boolean removeTodo(@PathVariable int no) {
		service.removeTodo(no);
		return true;
	}
	
	
//	boolean modifyTodo(Todo todo);
	@PutMapping("/{no}")
	public boolean modifyTodo(@PathVariable int no, @RequestBody Todo todo) {
		todo.setNo(no);
		service.modifyTodo(todo);
		return true;
	}

//	boolean addTodo(Todo todo);
	@PostMapping("/")
	public boolean addTodo(@RequestBody Todo todo) {
		service.addTodo(todo);
		return true;
	}
	
//	boolean completeTodo(int no);
	@PutMapping("/{no}/done")
	public boolean completeTodo(@PathVariable int no) {
		
		return service.completeTodo(no);
	}
}











