package com.ssafy.todo.dto;

public class Todo {
	private int no;
	private String content;
	private String id;
	private String write_date;
	private String end_date;
	private String done;
	public int getNo() {
		return no;
	}
	public void setNo(int no) {
		this.no = no;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getWrite_date() {
		return write_date;
	}
	public void setWrite_date(String write_date) {
		this.write_date = write_date;
	}
	public String getEnd_date() {
		return end_date;
	}
	public void setEnd_date(String end_date) {
		this.end_date = end_date;
	}
	public String getDone() {
		return done;
	}
	public void setDone(String done) {
		this.done = done;
	}
	public Todo(int no, String content, String id, String write_date, String end_date, String done) {
		super();
		this.no = no;
		this.content = content;
		this.id = id;
		this.write_date = write_date;
		this.end_date = end_date;
		this.done = done;
	}
	
	
	
}
