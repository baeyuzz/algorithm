package com.ssafy.emp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Hwsf06Seoul8BaeyujinApplicationTests {

	@Test
	void contextLoads() {
	}

}
