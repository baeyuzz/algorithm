package com.ssafy.java;

import java.util.Scanner;

public class GameTest {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);

		System.out.println("가위바위보 게임을 시작합니다. 아래보기 중 하나를 고르세요");
		System.out.println("1. 5판 3승");
		System.out.println("2. 3판 2승");
		System.out.println("3. 1판 1승");
		System.out.println("번호를 입력하세요");

		int num = sc.nextInt();
		int swt = 0, win = 0, lose = 0;

		if (num == 1) {
			win = 3;
			lose = 3;
		}
		if (num == 2) {
			win = 2;
			lose = 2;
		}
		if (num == 3) {
			win = 1;
			lose = 1;
		}

		while (true) {
			int com = (int) (Math.random() * 3) + 1;
			int my = 0;
			System.out.print("가위바위보 중 하나 입력 : ");

			String me = sc.next();

			if (me.equals("가위"))
				my = 1;
			if (me.equals("바위"))
				my = 2;
			if (me.equals("보"))
				my = 3;

			int diff = my - com;

			if (my == com) {
				System.out.println("비겼습니다");
			} else if ((my == 1 && diff == -1) || (my == 2 && diff == -1) || (my == 3 && diff == 2)) {
				System.out.println("졌습니다");
				lose--;
			} else {
				System.out.println("이겼습니다");
				win--;
			}

			if (win == 0) {
				break;
			}
			if (lose == 0) {
				swt = 1;
				break;
			}

		}
		String winner = "";
		if (swt == 0)
			winner = "사용자";
		else
			winner = "컴퓨터";

		System.out.println("### " + winner + " 승");

		sc.close();
	}
}
