package algo;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Arrays;
import java.util.Comparator;
import java.util.StringTokenizer;

public class Solution_D4_4050_재관이 {
	public static void main(String[] args) throws NumberFormatException, IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		int t = Integer.parseInt(br.readLine());
		for (int test = 0; test < t; test++) {
			int n;
			Integer c[];

			n = Integer.parseInt(br.readLine());
			c = new Integer[n];

			StringTokenizer st = new StringTokenizer(br.readLine(), " ");
			for (int i = 0; i < n; i++) {
				c[i] = Integer.parseInt(st.nextToken());
			}

			Arrays.sort(c, new Comparator<Integer>() {
				@Override
				public int compare(Integer o1, Integer o2) {
					return o2.compareTo(o1);
				}
			});

			int sum = 0;
			for (int i = n - 1; i >= 0; i--) {
				if (i % 3 == 2)
					continue;
				sum += c[i];

			}
			System.out.println("#" + (test + 1) + " " + sum);

		}
	}
}
