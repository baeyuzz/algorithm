export default {
  template: `
    <div>
      삭제완료
    </div>
    

  `,
  created() {
    const board = JSON.parse(localStorage.getItem('board'));
    this.no = this.$route.params.no;

    board.items = board.items.filter((item) => {
      return item.no != this.no;
    });
    localStorage.setItem('board', JSON.stringify(board));

    alert('삭제가 완료되었습니다.');
  },
};
