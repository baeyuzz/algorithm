export default {
  template: `
    <p>
      <router-link :to="{name:'main'}">Home</router-link>
      <router-link :to="{name:'list'}">게시판</router-link>
    </p>`,
};
