export default {
  template: `
  <div>
    <table class="table table-bordered w-50">



      <tr>
        <th>번호</th>
        <td>{{item.no}}</td>
      </tr>
      <tr>
        <th>글쓴이</th>
        <td>{{item.writer}}</td>
      </tr>
      <tr>
        <th>제목</th>
        <td>{{item.title}}</td>
      </tr>
      <tr>
        <th>날짜</th>
        <td>{{getFormatDate(item.regtime)}}</td>
      </tr>
      <tr>
        <td colspan="2">
          {{item.content}}
        </td>
      </tr>
    </table>
    <br />
    <div class="text-center">
      <a href="./list.html" class="btn btn-primary">목록</a>

      <router-link :to="{name: 'update', params: {no: item.no}}" class="btn btn-primary">수정</router-link>
      <router-link :to="{name: 'delete', params: {no: item.no}}" class="btn btn-primary">삭제</router-link>

  </div>
  `,
  data: function () {
    return {
      item: {},
    };
  },
  created() {
    const board = JSON.parse(localStorage.getItem('board'));
    this.no = this.$route.params.no;
    // console.log(this.no);
    for (let obj of board.items) {
      // console.log(obj.no);
      if (this.no == obj.no) {
        this.item = obj;
        break;
      }
    }
  },
  methods: {
    getFormatDate(regtime) {
      return moment(new Date(regtime)).format('YYYY.MM.DD HH:mm:ss');
    },
  },
};
