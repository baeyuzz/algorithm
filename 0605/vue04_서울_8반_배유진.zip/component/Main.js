export default {
    template: '<h2 class="text-center">Vue를 이용한 게시판</h2>',
  };
  