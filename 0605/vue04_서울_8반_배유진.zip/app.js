import Main from './component/Main.js';
import Read from './component/Read.js';
import Create from './component/Create.js';
import Update from './component/Update.js';
import List from './component/List.js';
import Delete from './component/Delete.js';
import NavHeader from './component/NavHeader.js';

const router = new VueRouter({
    mode: 'history',
    routes: [
        {
            path : '/',
            name : 'main',
            component : Main,
        },
        {
            path : '/list',
            name : 'list',
            components:{
                default:List,
                header:NavHeader,
              }       
             },
             {
                    path : '/create',
                    name : 'create',
                    components:{
                        default:Create,
                        header:NavHeader,
                      }
                },
                {
                    path : '/update',
                    name : 'update',
                    components:{
                        default:Update,
                        header:NavHeader,
                      }                },
                {
                    path : '/delete',
                    name : 'delete',
                    components:{
                        default:Delete,
                        header:NavHeader,
                      }                },
                {
                    path : '/list/:no',
                    name : 'read',
                    components:{
                        default:Read,
                        header:NavHeader,
                      }               
                    
                    }

    ]
});

const app = new Vue({
    el : "#app",
    router,
});