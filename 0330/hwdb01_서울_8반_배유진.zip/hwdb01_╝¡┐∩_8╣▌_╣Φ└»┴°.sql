use scott_hw;

create table emp
(empno int(4) primary key,
ename varchar(10),
job varchar(9),
mgr int(4),
hiredate date,
sal decimal(7,2),
comm decimal(7,2),
deptno int(2));

INSERT INTO EMP VALUES
(7369,'SMITH','CLERK',7902,cast('2010-10-19' as date),800,NULL,20);
INSERT INTO EMP VALUES
(7499,'ALLEN','SALESMAN',7698,cast('2000-10-19' as date),1600,300,30);
INSERT INTO EMP VALUES
(7521,'WARD','SALESMAN',7698,cast('2013-05-19' as date),1250,500,30);
INSERT INTO EMP VALUES
(7566,'JONES','MANAGER',7839,cast('2018-10-19' as date),2975,NULL,20);
INSERT INTO EMP VALUES
(7654,'MARTIN','SALESMAN',7698,cast('2008-04-19' as date),1250,1400,30);
INSERT INTO EMP VALUES
(7698,'BLAKE','MANAGER',7839,cast('2016-11-19' as date),2850,NULL,30);
INSERT INTO EMP VALUES
(7782,'CLARK','MANAGER',7839,cast('2017-10-19' as date),2450,NULL,10);
INSERT INTO EMP VALUES
(7788,'SCOTT','ANALYST',7566,cast('2013-10-11' as date),3000,NULL,20);
INSERT INTO EMP VALUES
(7839,'KING','PRESIDENT',NULL,cast('2014-08-19' as date),5000,NULL,10);
INSERT INTO EMP VALUES
(7844,'TURNER','SALESMAN',7698,cast('2010-10-19' as date),1500,0,30);
INSERT INTO EMP VALUES
(7876,'ADAMS','CLERK',7788,cast('2000-09-19' as date),1100,NULL,20);
INSERT INTO EMP VALUES
(7900,'JAMES','CLERK',7698,cast('2018-10-19' as date),950,NULL,30);
INSERT INTO EMP VALUES
(7902,'FORD','ANALYST',7566,cast('2003-10-19' as date),3000,NULL,20);
INSERT INTO EMP VALUES
(7934,'MILLER','CLERK',7782,cast('2002-10-19' as date),1300,NULL,10);



-- 1. 입사일이 2014년도인 사람의 모든 정보 검색

select *
from emp
where hiredate like '2014%';

-- 2. 이름 중 s가 들어가는 사람만 모든 정보 검색

select *
from emp
where ename like '%s%';

-- 3. 커미션이 null인 사람의 정보를 검색

select *
from emp
where comm is null;

-- 4. 30번 부서의 연봉을 계산하여 이름, 부서번호, 급여, 연봉(12개월 월급여 + 연말보너스)을 검색하세요. 단, 연말에 급여의 150%를 보너스로 지급한다.

select ename, deptno, sal, sal*13.5 salary
from emp
where deptno = 30;  

-- 5. 급여가 $2,000 이상인 모든 사람은 급여의 15%를 경조비로 내기로 하였다. 이름, 급여, 경조비를 검색하세요.

select ename, sal, sal*0.15 as '경조비'
from emp
where sal >= 2000;