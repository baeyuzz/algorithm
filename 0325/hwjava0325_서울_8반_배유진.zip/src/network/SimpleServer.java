package network;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Scanner;

//server
/**
 * 1. ServerSocket(port) 생성 2. ServerSocket.accept():클라이언트가 접속해오기를 기다렸다가 받는
 * 메소드-->Socket이 들어옴(client) 3. Socket으로부터 입출력 스트림 얻어냄 4. 스트림으로 메세지 전송 5. Socket
 * 닫기(close()) 6. 스트림 닫기
 */
public class SimpleServer {
	public static void main(String[] args) throws Exception {

		ServerSocket server; // 서버역할객체
		Socket client; // 서버로 접속해 들어온 클라이언트를 받을 객체
		OutputStream out; // 노드스트림
		DataOutputStream dos; // 필터스트림 특정 데이터 타입으로 출력

		String message = "I'm server..."; // 클라이언트한테 보낼 메세지

		server = new ServerSocket(8888);

		System.out.println("server : waiting client...");

		
		// while이 없으면 single-client
		while(true) { // mlti-client, accepting repeatedly
		client = server.accept();
		System.out.println("server : client connected");

		out = client.getOutputStream();
		dos = new DataOutputStream(out);
		
		dos.writeUTF(message);
		
		// revceived msg from client
		DataInputStream dis = new DataInputStream(client.getInputStream());


		System.out.println("msg from client : " + dis.readUTF());
		
		dos.close();
		out.close();
		dis.close();
		
		client.close(); // 하나의 client와 접속 끊음, while이라 다른 client 기다림 -> thread 이용해서 동시에 접속할 수 있도록 해야함
		}
		// server.close();
	}
}
