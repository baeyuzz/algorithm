package network;

import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;

public class NetworkSimpleServerMultiThread {

	public static void main(String[] args) {
		int port = 5088;
		try (ServerSocket ss = new ServerSocket(port)) {
			System.out.println("network simple server multi thread started");

			while (true) {
				Socket s = ss.accept();
				new SimpleServerThread(s).start();
			}
		} catch (IOException e) {
			System.out.println("network simple server multi thread exception : " + e.getMessage());
			e.printStackTrace();
		}
	}
}

class SimpleServerThread extends Thread {
	private Socket s;

	public SimpleServerThread(Socket s) {
		this.s = s;
	}

	public void run() {
		try {
			OutputStream output = s.getOutputStream();
			PrintWriter writer = new PrintWriter(output, true);
			writer.println("hello");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
