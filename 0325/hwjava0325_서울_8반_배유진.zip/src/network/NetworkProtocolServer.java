package network;

import java.net.ServerSocket;

public class NetworkProtocolServer {
	public static void main(String[] args) {
		try(ServerSocket ss = new ServerSocket(6547)){
			
		} catch (Exception e) {
			// TODO: handle exception
		}
	}
}
