package app;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.Random;
import java.util.stream.Stream;

import virus.Virus;

public class StreamCreationTest {
	public static void main(String[] args) {

		// youtube live
		{
			String[] strArr = { "A", "B", "C", "A", "D", "B" };

			Stream<String> stream = Stream.of(strArr);

			Stream<String> stream2 = stream.distinct();
			// print(stream);
			print(stream2);

		}

		{
			// lambda expression
			Stream<Integer> stream = Stream.generate(() -> {
				return new Random().nextInt(10);
			}).limit(5); // generate 는 무한대로 생성돼서 limit 걺
			print(stream);
		}

		{
			// lambda expression
			Stream<Integer> stream = Stream.iterate(1, n -> n + 2).limit(10);
			print(stream);
		}

		{
			Integer[] intarr = { 4, 3, 5, 1, 2 };
			Stream<Integer> stream = Arrays.stream(intarr);
			Stream<Integer> streamNew = stream.map(n -> n * 10);
			print(streamNew);
		}

		{
			Virus[] virusArr = { new Virus("v1", 10), new Virus("v2", 20), new Virus("v3", 30) };
			Stream<Virus> stream = Arrays.stream(virusArr);
			Stream<String> streamNew = stream.map(virus -> virus.getName());
			print(streamNew);
		}

		{
			String[] strarr = { "a", "b", "c", "d", "e", "f" };

			System.out.println("parallel");

			Stream<String> stream = Arrays.stream(strarr).parallel();
			stream.forEach(s -> System.out.print(s));

			System.out.println();
			stream = Arrays.stream(strarr).parallel();
			stream.forEach(System.out::print);
		}

		System.out.println();
		System.out.println("=====================================");
		System.out.println("zoom");
		System.out.println("=====================================");
		// ZOOM
		{
			new Thread(new Runnable() {

				@Override
				public void run() {
					System.out.println("run");
				}
			}).start();
			// anonymous

			new Thread(() -> {
				System.out.println("run2");
			}).start();
			// lambda
		}

		{ // compare function lambda화
			Integer[] arr = { 3, 5, 1, 2, 6, 4 };
			System.out.println(Arrays.toString(arr));

			Arrays.sort(arr, new Comparator<Integer>() {
				public int compare(Integer o1, Integer o2) {
					return o2 - o1; // 큰 -> 작 순서
				};
			});
			System.out.println(Arrays.toString(arr));

			Arrays.sort(arr, (o1, o2) -> o2 - o1);

			Arrays.sort(arr, (o1, o2) -> {
				return o2 - o1;
			});

			Arrays.sort(arr, (Integer o1, Integer o2) -> {
				return o2 - o1;
			});

			// 3개 다 됨, data type 생략 가능, return 생략 시 {}도 생략

			System.out.println(Arrays.toString(arr));
		}

		{
			// functional interface test
			System.out.println("calable 1 class");
			Calable c = new Calable() {
				public int sum(int a, int b) {
					return a + b;
				};
			};

			System.out.println(c.sum(10, 20));

			Calable c2 = (a, b) -> a + b;
			System.out.println(c2.sum(10, 30));

			System.out.println("calable2 class");
			Calable2 c3 = (a, b) -> a + b;
			System.out.println(c3.sum(30, 20));
			System.out.println(c3.mul(30, 20));
		}

		{
			// Stream API
			// data source를 변경하지 않는다
			// 일회용
			// 작업을 내부 반복으로 처리

			System.out.println("stream1");

			List<String> names = new ArrayList<>();
			names.add("김이");
			names.add("이임");
			names.add("박김");
			names.add("최정");

			int cnt = 0;
			for (String s : names) {
				if (s.contains("이")) {
					++cnt;
				}
			}
			System.out.println(cnt);

			long cnt2 = names.stream().filter( n -> n.contains("이")).count();
			System.out.println(cnt2);

			// stream 사용 순서
			// 1. create stream
			// - collection.stream()
			// - Arrays.tream(T[])
			// 2. stream 중간 연산 (0번이상) - list.stream(), filter(), map()
			// 3. 스트림 최종 연산 - 1번, count(), foreach()

			System.out.println("stream2");
			Stream<String> st1 = names.stream();
			System.out.println(st1.count());

			Integer[] arr = { 10, 4, 30, 5 };
			Stream<Integer> st2 = Arrays.stream(arr);
			long cnt3 = st2.filter(e -> e >= 10).count();
			System.out.println(cnt3);

			Stream<Integer> st3 = Stream.of(1, 4, 3, 4, 2, 2);
//			print(st3.distinct());
//			System.out.println(st3.count()); // 재사용 불가
			System.out.println(st3.distinct().count());
			// st3를 직접 연산 하는 것이 아닌 distinct된 새 임시 stream에 count 연산

		}
	}

	private static interface Calable {
		int sum(int a, int b);
	}

	@FunctionalInterface
	private static interface Calable2 {
		int sum(int a, int b);

		default int mul(int a, int b) {
			return a * b;
		}
	}

	public static void print(Stream<?> stream) {
		stream.forEach(a -> System.out.print(a + " "));
		System.out.println();
	}

}
