package app;

public class CoronaThreadLambdaTest {
	public static void main(String[] args) {
		new Thread(new Runnable() {

			@Override
			public void run() {
				System.out.println("anonymous thread 생성");
			}
		}).start();

		new Thread(() -> System.out.println("lambda thread 생성")).start();
	}

}
