<template>
    <div>
        <img src="../assets/logo.png" alt="logo">
        <h1>Todo List</h1>
    </div>
</template>

<script>
    export default {
        
    }
</script>

<style scoped>
h1 {
  color: #2f3b52;
  font-weight: 900;
  margin: 2.5rem 0 1.5rem;
}

</style>