<template>
    <div>
        <span class="clearAllBtn" @click="clearTodo">Clear All</span>
    </div>
</template>

<script>
    import { EventBus } from "../eventbus";
    import axios from 'axios';
    export default {
        methods: {
            clearTodo(){
                console.log("clear todo")
                axios.delete('http://127.0.0.1:8088/todolist/user/java')
                .then(()=>{ 
                  EventBus.$emit("input");
                })
                .catch( ()=>alert('삭제 실패'));
            }
        },
    }
</script>

<style scoped>

.clearAllContainer {
    width: 8.5rem;
    height: 50px;
    line-height: 50px;
    background-color: white;
    border-radius: 5px;
    margin: 0 auto;
  }
  .clearAllBtn {
    color: #e20303;
        /* 추가 */
        display: block;
  }
</style>