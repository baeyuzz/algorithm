<template>
    <div class="inputBox">

      <span>
        <label for="content"> 할일입력 </label>
        <input type="text" class="form-control" id="content" placeholder="할일 입력" v-model="content">
      </span>
      <span>
        <label for="end_date"> 기한 </label>
        <input type="text" class="form-control" id="end_date" placeholder="연도.월.일" v-model="end_date">
      </span>
         <span class="addContainer">
            <div class="addBtn fas fa-plus" aria-hidden='true' @click="AddTodo"></div>
        </span>
    </div>
</template>

<script>
    import { EventBus } from '../eventbus.js';

    import axios from 'axios';
    export default {
      data() {
        return {
          content : "", 
          end_date : ""
        }
      },
        methods: {
            AddTodo(){
                console.log("Add todo");
                 axios({
                   url: 'http://127.0.0.1:8088/todolist/todo',
                    method: 'post',
                    data: {
                      content: this.content,
                      userId : 'java',
                      endDate: this.end_date,
                    },
                 })
                .then( ()=>{ 
                  EventBus.$emit("input");
                })
                .catch( ()=>alert('추가 실패'));
                },
            }
        }

</script>

<style scoped>

input:focus {
  outline: none;
}
.inputBox {
  background: white;
  height: 50px;
  line-height: 50px;
  border-radius: 5px;
}
.inputBox input {
  border-style: none;
  font-size: 0.9rem;
}
.addContainer {
  float: right;
  background: linear-gradient(to right, #6478FB, #8763FB);
  display: inline-block;
  width: 3rem;
  border-radius: 0 5px 5px 0;
}
.addContainer2 {
  float: right;
  background: linear-gradient(to right, #647811, #527810);
  display: inline-block;
  width: 3rem;
  border-radius: 0 5px 5px 0;
}
.modifyBtn, .addBtn {
  color: white;
  vertical-align: middle;
} 

</style>