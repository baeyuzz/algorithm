<template>
    <div>
        <ul>
            <li v-for="(todoItem) in todoItems" v-bind:key="todoItem.no" class="shadow" :class="{done:todoItem.done=='Y'}">
                <i class="checkBtn fas fa-check" v-show="todoItem.done == 'N'" @click="done(todoItem.no)"></i>
                    {{todoItem.content}}  {{todoItem.writeDate}} - {{todoItem.endDate}}
                <span class="removeBtn" type = "button">
                    <i class="far far-trash-alt" @click="remove(todoItem.no)" >del</i>
                </span>
            </li>
        </ul>
    </div>
</template>

<script>
    import axios from 'axios';
    import { EventBus } from "../eventbus.js";
    export default {
        data() {
            return {
                todoItems : []
            }
        },
        created() {
            this.getTodoList();
            EventBus.$on("input",()=>this.getTodoList());
            EventBus.$on("deleteAll",()=>this.getTodoList());

        },
        methods: {
          getTodoList(){
            axios.get("http://127.0.0.1:8088/todolist/user/java")
                .then(response => this.todoItems = response.data)
                .catch(exp => alert('목록 조회 실패' + exp));
            },
            remove(no){
              axios.delete("http://127.0.0.1:8088/todolist/todo/"+no);
              this.getTodoList();
            },
            done(no){
              axios.put("http://127.0.0.1:8088/todolist/todo/done/"+no);
              this.getTodoList();
            }
        },
    }

</script>

<style scoped>

ul {
  list-style-type: none;
  padding-left: 0px;
  margin-top: 0;
  text-align: left;
}
li {
  display: flex;
  min-height: 50px;
  height: 50px;
  line-height: 50px;
  margin: 0.5rem 0;
  padding: 0 0.9rem;
  background: white;
  border-radius: 5px;
}
.checkBtn {
  line-height: 45px;
  color: #62acde;
  margin-right: 5px;
}
.removeBtn {
  margin-left: auto;
  color: #de4343;
}

.list-item {
  display: inline-block;
  margin-right: 10px;
}
.list-move {
  transition: transform 1s;
}
.list-enter-active,
.list-leave-active {
  transition: all 1s;
}
.list-enter,
.list-leave-to {
  opacity: 0;
  transform: translateY(30px);
}
.done{
  background-color: lightslategray;
}

</style>