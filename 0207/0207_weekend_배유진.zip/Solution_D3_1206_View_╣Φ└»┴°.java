import java.util.Scanner;
 
public class Solution {
    public static void main(String[] args) {
        int tc, n, b[];
        int map[][];
        int building;
 
        Scanner sc = new Scanner(System.in);
 
        tc = 10;
 
        for (int test = 0; test < tc; test++) {
            int total = 0;
 
            n = sc.nextInt();
 
            map = new int[n][255];
 
            b = new int[n];
            int s = b.length;
            for (int i = 0; i < s; i++) {
                b[i] = sc.nextInt(); // ������ �Է� ���� �ִ� 255
                building = b[i];
 
                for (int j = 0; j < building; j++) {
                    map[i][j] = 1;
 
                }
            }
//          for (int i = 0; i < n; i++) {
//              for(int j = 0;j<255;j++) {
//                  System.out.print(map[i][j]);
//              }
//              System.out.println();
//          }
 
            // �Է� �� ��????
 
            int[] dx = { 1, -1 };
 
            for (int x = 0; x < n; x++) {
                for (int y = 0; y < 255; y++) {
                    int cnt = 4;
                    int tmp = 0;
 
                    if (map[x][y] == 1) {
//                      System.out.println("1");
//                      tmpcnt++;
                        for (int i = 0; i < 2; i++) { // up down
                            int tx = x;
 
                            for (int k = 0; k < 2; k++) { // 2ĭ��
 
                                tx += dx[i];
 
                                if (tx < n && tx >= 0) {
                                    if (map[tx][y] == 0) {
                                        // System.out.println(++tmp);
                                        cnt--;
                                        if (cnt == 0) {
                                            total++;
                                        } // System.out.println(cnt);
                                    }
                                }
                            }
                        }
 
                    }
                }
            }
            System.out.println("#" + (test + 1) + " " + total);
        }
    }
}