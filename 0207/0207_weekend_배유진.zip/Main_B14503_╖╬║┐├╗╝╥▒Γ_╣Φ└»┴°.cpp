#include<iostream>
int main() {
	int n, m, cnt=0, p[50][50], dir, x, y, dy[4] = { 0,1,0,-1 }, dx[4] = { -1,0,1,0 }, res = 0;

	scanf("%d%d%d%d%d", &n,&m,&x,&y,&dir); // inputs
	for (int i = 0; i < n; i++)
		for (int j = 0; j < m; j++)
			scanf("%d", &p[i][j]);
	
	while (1) {
		if (p[x][y] == 0)
			p[x][y] = 2;

		int i;
		for (i = 0; i < 4; i++) {
			dir = (dir + 3) % 4;
			if (p[x + dx[dir]][y + dy[dir]] == 0) {
				x = x + dx[dir];
				y = y + dy[dir];
				break;
			}
		}


		if (i == 4) {
			int ndir = (dir + 2) % 4;
			x = x + dx[ndir];
			y = y + dy[ndir];

			if (p[x][y] == 1)
				break;

			}
		
	}
	for (int i = 0; i < n; i++)
		for (int j = 0; j < m; j++)
			if (p[i][j] == 2)
				res++;
		
	printf("%d", res);
	return 0;

	}