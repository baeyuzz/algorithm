package com.ssafy.product.service;

import java.util.List;

import com.ssafy.product.dto.Product;

public interface ProductService {
	public List<Product>  searchAll();
	public Product search(String isbn);
	public void insert(Product book);
	public void update(Product book);
	public void delete(String isbn);
}



