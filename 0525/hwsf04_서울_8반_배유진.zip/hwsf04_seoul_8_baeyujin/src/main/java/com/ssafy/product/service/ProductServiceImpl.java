package com.ssafy.product.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ssafy.product.dao.ProductDao;
import com.ssafy.product.dto.Product;

@Service
public class ProductServiceImpl implements ProductService {
	
	private ProductDao dao;
	@Autowired
	public void setDao(ProductDao dao) {
		this.dao = dao;
	}
	public List<Product> searchAll() {
		return dao.searchAll();
	}
	public Product search(String isbn) {
		return dao.search(isbn);
	}
	public void insert(Product book) {
		dao.insert(book);
	}
	public void update(Product book) {
		dao.update(book);
	}
	public void delete(String isbn) {
		dao.delete(isbn);
	}
}
