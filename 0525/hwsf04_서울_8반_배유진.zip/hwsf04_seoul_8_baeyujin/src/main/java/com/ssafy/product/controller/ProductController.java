package com.ssafy.product.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.ssafy.product.dto.Product;
import com.ssafy.product.service.ProductService;

@RestController
public class ProductController {

	private ProductService productService;
	@Autowired
	public void setproductService(ProductService productService) {
		this.productService = productService;
	}

	@GetMapping("/product")
	public List<Product> getproductList() {
		return productService.searchAll();
	}
	
	@GetMapping("/product/{id}")
	public Map<String,Object> getproduct(@PathVariable String id) {
		Product product = productService.search(id);
		HashMap<String,Object> map = new HashMap<String,Object>();
		map.put("status", (product != null)?true:false);
		if(product != null) map.put("result" , product);
		return map;
	}
	
	
	
	@DeleteMapping("/product/{id}")
	public boolean remomveproduct(@PathVariable String id) {
		productService.delete(id);
		return true;
	}
	@PutMapping("/product/{id}")
	public boolean modifyproduct(@RequestBody Product product) {
		productService.update(product);
		return true;
	}
	
	@PostMapping("/product")
	public boolean registerproduct(@RequestBody Product product) {
		productService.insert(product);
		return true;
	}
}