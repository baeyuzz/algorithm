package virus;

public class Corona extends Virus {
	private String spreadSpeed;

	public String getSpreadSpeed() {
		return spreadSpeed;
	}

	public void setSpreadSpeed(String spreadSpeed) {
		this.spreadSpeed = spreadSpeed;
	}

	public Corona(int level, String name, String spreadSpeed) {
		super(level, name);
		this.spreadSpeed = spreadSpeed;
	}

}
