package medical;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import person.Patient;

public class CDC extends Organization {

	private List<Hospital> hospitalList = new ArrayList<Hospital>();
	private Set<Patient> patientList = new HashSet<Patient>();

	public CDC() {
	}

	public CDC(String name, int employeeCount, List<Hospital> hospitalList, Set<Patient> patientList) {
		super(name, employeeCount);
		this.hospitalList = hospitalList;
		this.patientList = patientList;
	}

	public List<Hospital> getHospitalList() {
		return hospitalList;
	}

	public void setHospitalList(List<Hospital> hospitalList) {
		this.hospitalList = hospitalList;
	}

	public Set<Patient> getPatientList() {
		return patientList;
	}

	public void setPatientList(Set<Patient> patientList) {
		this.patientList = patientList;
	}

	public void about() { // overriding
		super.about();
		System.out.println("We managed Hospital and Patients");
	}

	public void about(String more) { // overloading
		System.out.println("We are CDC");
	}

	public void addPatient(Patient p) {
		patientList.add(p);
	}
	public void removePatient(Patient p) {
		patientList.remove(p);
	}

}
