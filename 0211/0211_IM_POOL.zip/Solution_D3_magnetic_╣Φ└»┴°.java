import java.util.Scanner;
 
public class Solution_D3_magnetic_������ {
 
    public static void main(String[] args) {
        int t, n, map[][];
        boolean cur[][];
 
        t = 10;
        Scanner sc = new Scanner(System.in);
 
        for (int test = 0; test < t; test++) {
            n = sc.nextInt();
            map = new int[n][n];
 
            for (int i = 0; i < n; i++) {
                for (int j = 0; j < n; j++) {
                    map[i][j] = sc.nextInt();
                }
            }
 
            for (int i = 0; i < n; i++) {
                for (int j = 0; j < n; j++) {
                    if (map[i][j] == 1) {
 
                        int x = i;
                        int y = j;
 
                        map[x][y] = 0;
 
                        while (true) {
                            x += 1;
 
                            if (x < n) {
                                if (map[x][y] == 1) {
                                    break;
                                }
                                if (map[x][y] == 2 || map[x][y] == 4 || map[x][y] == 3) { // ���� �ö󰡴� �� ������,,
                                    map[x - 1][y] = 3;
                                    break;
                                }
                            }
                            if (x >= n - 1) {
                                break;
                            }
                        }
                    }
                    if (map[i][j] == 2) { // �ö󰡴� ��
                        int x = i;
                        int y = j;
 
                        map[i][j] = 0;
 
                        while (true) {
 
                            x += -1;
 
                            if (x >= 0) {
                                if (map[x][y] == 2)
                                    break;
                                if (map[x][y] == 1 || map[x][y] == 4 || map[x][y] == 3) { // ���� �ö󰡴� �� ������,,
                                    map[x + 1][y] = 4;
                                    break;
                                }
                            }
                                if (x < 0)
                                    break;
 
                             
                        }
                    }
 
                }
            }
//          for (int i = 0; i < n; i++) {
//              for (int j = 0; j < n; j++) {
//                  System.out.print(map[i][j] + " ");
//
//              }
//              System.out.println();
//          }
 
            int cnt = 0;
            for (int x = 0; x < n-1; x++) {
                for (int y = 0; y < n; y++) {
                    if (map[x][y] == 3 && map[x + 1][y] == 4) {
                        cnt++;
                    }
                }
            }
            System.out.println("#" + (test+1)+ " "+cnt);
        }
 
    }
 
}