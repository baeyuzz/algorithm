import java.util.Scanner;
 
public class Solution_D2_�ĸ���ġ_������ {
    public static void main(String[] args) {
        int t, n, m, map[][];
 
        Scanner sc = new Scanner(System.in);
 
        t = sc.nextInt();
 
        for (int test = 0; test < t; test++) {
            n = sc.nextInt();
            m = sc.nextInt();
 
            map = new int[n][n];
 
            for (int x = 0; x < n; x++) {
                for (int y = 0; y < n; y++) {
                    map[x][y] = sc.nextInt();
                }
            }
 
            //
 
            int max = 0;
 
            for (int i = 0; i < n; i++) {
                for (int j = 0; j < n; j++) {
 
                    int sum = 0;
 
                    for (int k = i; k < i + m; k++) {
                        for (int l = j; l < j + m; l++) {
                            if (k < n && l < n)
                                sum += map[k][l];
                        }
 
                    }
 
                    if (max < sum) {
                        max = sum;
                    }
 
                }
 
            }
            System.out.println("#" + (test + 1) + " " + max);
 
        }
    }
}