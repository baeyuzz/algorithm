import java.util.Scanner;
  
public class Solution_D3_Sum_������ {
    public static void main(String[] args) {
        int t, n, map[][];
  
        Scanner sc = new Scanner(System.in);
  
        t = 10;
        n = 100;
        for (int test = 0; test < t; test++) {
  
            sc.nextInt();
            map = new int[n][n];
            for (int x = 0; x < n; x++) {
                for (int y = 0; y < n; y++) {
                    map[x][y] = sc.nextInt();
                }
            }
  
            int xsum = 0;
            int ysum = 0;
            int rsum = 0;
            int lsum = 0;
            int max = 0;
  
            for (int x = 0; x < n; x++) {
                for (int y = 0; y < n; y++) {
                    xsum += map[x][y];
                }
                if (max < xsum) {
                    max = xsum;
                }
                xsum = 0;
            }
            for (int x = 0; x < n; x++) {
                for (int y = 0; y < n; y++) {
                    ysum += map[y][x];
                }
                if (max < ysum) {
                    max = ysum;
                }
                ysum = 0;
            }
  
            for (int x = 0, y = 0; x < n && y < n; y++, x++) {
                rsum += map[x][y];
  
                if (max < rsum) {
                    max = rsum;
                }
            rsum = 0;
            }
  
            for (int x = n-1, y = n-1; x >=0  && y >=0; y--, x--) {
                lsum += map[x][y];
                if (max < lsum) {
                    max = lsum;
                }
                lsum = 0;
            }
            System.out.println("#" + (test+1)+ " "+max);
        }
    }
}