import java.util.Scanner;
  
public class Solution_D3_���۹���Ȯ�ϱ�_������ {
    static int sum, m, n, t, map[][];
  
    public static void main(String[] args) {
  
        Scanner sc = new Scanner(System.in);
  
        t = sc.nextInt();
  
        for (int test = 0; test < t; test++) {
            n = sc.nextInt();
  
            sum = 0;
  
            map = new int[n][n];
              
            for (int i = 0; i < n; i++) {
                String tmp = sc.next();
                for (int j = 0; j < n; j++) {
                    map[i][j] = tmp.charAt(j) - 48;
                    sum += map[i][j];
                }
            }
  
            m = n / 2;
            dfs(m);
            System.out.println("#" + (test+1) + " " + sum);
  
        }
    }
  
    static void dfs(int k) {
        for (int i = 0; i < k; i++) {
            sum -= map[i][k - i - 1];
            map[i][k - i - 1] = 0;
        }
        for (int i = n - k, j = 0; i < n && j < k; j++, i++) {
            sum -= map[j][i];
            map[j][i] = 0;
        }
  
        for (int i = k - 1, j = n - 1; i >= 0 && j >= n - 1 - k; j--, i--) {
            sum -= map[j][i];
            map[j][i] = 0;
        }
  
        for (int i = n - k, j = n - 1; i <= n - 1 && j >= n - k-1; i++, j--) {
            sum -= map[j][i];
            map[j][i] = 0;
        }
        if (k - 1 >= 0)
            dfs(k - 1);
    }
}