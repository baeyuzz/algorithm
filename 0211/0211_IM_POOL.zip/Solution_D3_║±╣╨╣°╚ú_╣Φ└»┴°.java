import java.util.ArrayList;
import java.util.Scanner;
 
public class Solution_D3_��й�ȣ_������ {
    public static void main(String[] args) {
        int t, n;
        String arr;
 
        Scanner sc = new Scanner(System.in);
 
        t = 10;
 
        for (int test = 0; test < t; test++) {
            n = sc.nextInt();
            arr = sc.next();
 
            int len = arr.length();
            ArrayList<Integer> list = new ArrayList<Integer>();
 
            for (int i = 0; i < len; i++) {
                list.add((int) arr.charAt(i) - 48);
            }
 
            for (int i = 0; i < list.size()-1; i++) {
                if (list.get(i) == list.get(i + 1)) {
                    list.remove(i);
                    list.remove(i);
                    i = -1;
 
                }
 
            }
            System.out.print("#" + (test + 1) + " ");
 
            len = list.size();
            for (int i = 0; i < len; i++) {
                System.out.print(list.get(i));
            }
            System.out.println();
        }
    }
}