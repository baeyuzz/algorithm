package com.ssafy.model.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ssafy.model.dto.Product;
import com.ssafy.model.repository.ProductRepo;

@Component("productService")
public class ProductServiceImpl implements ProductService {

	private ProductRepo pr;

	@Autowired
	public void setPr(ProductRepo pr) {
		this.pr = pr;
	}

	@Override
	public ProductRepo getRepo() {
		return pr;
	}

	@Override
	public List<Product> selectAll() {
		return pr.selectAll();
	}

	@Override
	public Product select(String id) {
		return pr.select(id);
	}

	@Override
	public int insert(Product product) {
		return pr.insert(product);
	}

	@Override
	public int update(Product product) {
		return pr.update(product);
	}

	@Override
	public int delete(String id) {
		return pr.delete(id);
	}

}
