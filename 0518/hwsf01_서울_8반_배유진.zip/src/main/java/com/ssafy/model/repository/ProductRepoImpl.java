package com.ssafy.model.repository;

import java.util.List;

import com.ssafy.model.dto.Product;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component("productRepository")
public class ProductRepoImpl implements ProductRepo {

	@Override
	public List<Product> selectAll() {
		String sql = "select * from product";
		return null;
	}

	@Override
	public Product select(String id) {
		String sql = "select * from product where id like ?";

		return new Product(id, "asdf", 1234, "asdf");
	}

	@Override
	public int insert(Product product) {
		String sql = "insert into product ";
		return 0;
	}

	@Override
	public int update(Product product) {
		String sql = "update";
		return 0;
	}

	@Override
	public int delete(String id) {
		String sql = "delete from product where id = ?";
		return 0;
	}

}
