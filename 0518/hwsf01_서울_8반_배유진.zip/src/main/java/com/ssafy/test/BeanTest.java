package com.ssafy.test;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.ssafy.model.service.ProductService;

public class BeanTest {
	public static void main(String[] args) {
		ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("beans.xml");

		ProductService bean = (ProductService) context.getBean("productService"); // bean의 id로 찾음

		bean.getRepo();
		System.out.println(bean.select("153").toString());
		bean.delete("123");

		context.close();
	}
}
