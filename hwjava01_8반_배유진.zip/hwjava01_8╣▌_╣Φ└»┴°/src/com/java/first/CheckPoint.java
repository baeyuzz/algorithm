package com.java.first;

import java.util.Scanner;

public class CheckPoint {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int diff=0;
		int h = sc.nextInt();
		int w = sc.nextInt();
		diff = w+100-h;
		System.out.println("비만수치는 " + diff + "입니다");
	} 
}
