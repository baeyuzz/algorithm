package com.java.first;

public class CircleArea {
	public static void main(String[] args) {
		System.out.println("반지름이 5cm인 원의 넓이는 " + 5*5*3.14 + "입니다");
	}

}
