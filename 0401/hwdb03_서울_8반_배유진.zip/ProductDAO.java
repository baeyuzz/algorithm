
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class ProductDAO {

	static {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
//			Connection con = DriverManager.getConnection(
//					"jdbc:mysql://127.0.0.1:3306/scott?serverTimezone=UTC&useUniCode=yes&characterEncoding=UTF-8",
//					"ssafy", "ssafy"); // scott schema 쓰고 로그인은 ssafy 계정으로
//
//			// 3. statement
//			Statement st = con.createStatement();
//
//			// 4. sql execute
//			String sql = "create table product(isbn int primary key, price int, name varchar(20))";
//			st.execute(sql);
//
//			// 5. close
//			st.close();
//			con.close();

		} catch (ClassNotFoundException e) {
			System.out.println("class loading failed");
//		} catch (SQLException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
		}
	}
	String id = "ssafy";
	String pw = "ssafy";
	String url = "jdbc:mysql://127.0.0.1:3306/scott?serverTimezone=UTC&useUniCode=yes&characterEncoding=UTF-8";

	public ArrayList<Product> findAll() {

		ArrayList<Product> list = new ArrayList<Product>();

		String query = "select * from product";
		Connection con = null;
		PreparedStatement st = null;
		ResultSet rs = null;

		try {
			con = DriverManager.getConnection(url, id, pw);

			st = con.prepareStatement(query);

			rs = st.executeQuery();

			while (rs.next()) {

				int isbn = rs.getInt(1);
				int price = rs.getInt(2);
				String name = rs.getString(3);

				list.add(new Product(isbn, price, name));

			}
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("failed");
		}
		return list;

	}

	public Product findByisbn(int isbn) {
		String query = "select * from product where isbn = ?";
		Connection con = null;
		PreparedStatement st = null;
		ResultSet rs = null;

		Product c = null;

		try {
			con = DriverManager.getConnection(url, id, pw);

			st = con.prepareStatement(query);
			st.setInt(1, isbn);

			rs = st.executeQuery();

			if (rs.next()) {

				isbn = rs.getInt(1);
				String name = rs.getString(3);
				int price = rs.getInt(2);

				c = new Product(isbn, price, name);
			}
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("failed");
		}

		return c;
	}

	public int insert(int isbn, int price, String name) {
		String query = "insert into product values(?,?,?);";
		Connection con = null;
		PreparedStatement st = null;

		try {
			con = DriverManager.getConnection(url, id, pw);

			st = con.prepareStatement(query);
			st.setInt(1, isbn);
			st.setInt(2, price);
			st.setString(3, name);

			st.executeUpdate();

		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("failed");
		}

		return 0;
	}

	public void delete(int isbn) {
		String query = "delete from product where isbn = ?";
		Connection con = null;
		PreparedStatement st = null;

		try {
			con = DriverManager.getConnection(url, id, pw);

			st = con.prepareStatement(query);
			st.setInt(1, isbn);

			st.executeUpdate();

		} catch (Exception e) {
			System.out.println("failed");
		}

	}

	public int updatePrice(int isbn, int price) {

		String query = "update product set price = ? where isbn = ?";
		Connection con = null;
		PreparedStatement st = null;
		ResultSet rs = null;

		try {
			con = DriverManager.getConnection(url, id, pw);

			st = con.prepareStatement(query);
			st.setInt(1, price);
			st.setInt(2, isbn);

			st.executeUpdate();
			
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("failed");
		}

		return 0;
	}

}
