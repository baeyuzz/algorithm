
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Product {
		int isbn, price;
	String name;

	public Product() {
	}

	public int getIsbn() {
		return isbn;
	}

	public void setIsbn(int isbn) {
		this.isbn = isbn;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Product(int isbn, int price, String name) {
		super();
		this.isbn = isbn;
		this.price = price;
		this.name = name;
	}

	@Override
	public String toString() {
		return "Product [isbn=" + isbn + ", price=" + price + ", name=" + name + "]";
	}

}
