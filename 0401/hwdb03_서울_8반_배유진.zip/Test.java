
import java.util.List;

public class Test {
	public static void main(String[] args) {
		ProductDAO d = new ProductDAO();
		d.insert(123, 1000, "monitor");
		d.insert(234, 2500, "tv");
		d.insert(564, 3200, "pc");

		List<Product> list = d.findAll();

		Product tmp = d.findByisbn(123);
		System.out.println(tmp);

		d.delete(123);
		
		System.out.println();
		
		d.updatePrice(2600,234);
		
		for (Product p : list) {
			System.out.println(p);
		}
	}
}
