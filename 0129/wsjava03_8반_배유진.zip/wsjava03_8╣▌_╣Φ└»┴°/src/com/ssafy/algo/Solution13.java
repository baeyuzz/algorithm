package com.ssafy.algo;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class Solution13 {
	static int n;
	static char map[][];

	public static void main(String[] args) throws FileNotFoundException {
		System.setIn(new FileInputStream("solution.txt"));

		Scanner sc = new Scanner(System.in);

		int t = sc.nextInt();

		for (int test = 0; test < t; test++) {

			n = sc.nextInt();
			map = new char[n][n];

			for (int i = 0; i < n; i++) {
				for (int j = 0; j < n; j++) {
					map[i][j] = sc.next().charAt(0);
				}
			} // map 입력

			int dx[] = { -1, 1, 0, 0, -1, -1, 1, 1 }; // 8방
			int dy[] = { 0, 0, -1, 1, -1, 1, -1, 1 };

//			int sum[][] = new int[n][n];
			int count[][] = new int[n][n];

			for (int x = 0; x < n; x++) {
				for (int y = 0; y < n; y++) {
					int cnt = 0;

					if (map[x][y] == 'B') { // b 이면 주변 8 방향 탐색
						for (int d = 0; d < 8; d++) {
							x += dx[d];
							y += dy[d];

							if (x < n && y < n && x >= 0 && y >= 0) {
								if (map[x][y] != 'B') { // 주변에 g 있으면 ++
									cnt++;
								}
							}
							x -= dx[d];
							y -= dy[d];
							// 원래 x로 돌아오게 하기~ tx를 쓰는 게 나은가?
						}
						count[x][y] = cnt; // 0인 애들(주변이 다 B인애들)을 중심으로 건물 쌓을 것임
					} else
						count[x][y]++;
				}
			}

			// 여기부터는 4방 탐색으로 건물 층수 카운팅
			int max = 0;

			for (int x = 0; x < n; x++) {
				for (int y = 0; y < n; y++) {
					if (count[x][y] == 0) { // 건물2 층이상 쌓을 수 있는 곳임
						int cnt = 1;

						for (int d = 0; d < 4; d++) { // 4방 탐색
							int num = n;
							int tx = x;
							int ty = y;

							while (true) { // 범위 안 벗어나게 탐색,,,
								tx += dx[d];
								ty += dy[d];
								if (tx < n && ty < n && tx >= 0 && ty >= 0) {
									if (map[tx][ty] == 'B') {
										cnt++; // 4방 누적해서 ++
									}
								}
								num--;
								if (num == 0) {
									break;
								}
							}
							if (max < cnt)
								max = cnt;
						}
					}
				}
			}
			System.out.println(max);
		}
	}
}
