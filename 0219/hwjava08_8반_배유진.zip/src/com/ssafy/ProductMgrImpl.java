package com.ssafy;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

public class ProductMgrImpl {

	List<Product> products = new ArrayList<>();

	public void add(Product p) {
		if (p instanceof Refrigerator) {
			products.add(new Refrigerator(p.getIsbn(), p.getName(), p.getPrice(), p.getAmount(),
					((Refrigerator) p).getLitter()));
		} else if (p instanceof TV) {
			products.add(new TV(p.getIsbn(), p.getName(), p.getPrice(), p.getAmount(), ((TV) p).getInch()));
		}
	}

	public List<Product> search() {
		System.out.println();

		System.out.println("======전체 출력======");
		return products;

	}

	List<Product> search(int isbn) {

		System.out.println();
		System.out.println("=============================isbn 검색=============================");

		int index = 0;
		List<Product> pros = new ArrayList<>();

		Iterator<Product> it = products.iterator();

		while (it.hasNext()) {
			if (it.next().getIsbn() == isbn) {
				pros.add(products.get(index));
			}
			index++;
		}
		return pros;

	}

	List<Product> searchPro(String name) {

		System.out.println();
		System.out.println("=============================상품명 검색=============================");

		int index = 0;
		List<Product> pros = new ArrayList<>();

		Iterator<Product> it = products.iterator();

		while (it.hasNext()) {
			if (it.next().getName().contains(name)) {
				pros.add(products.get(index));
			}
			index++;
		}

		return pros;
	}

	List<TV> printTV() {
		System.out.println();
		System.out.println("=============================TV=============================");

		List<TV> tv = new ArrayList<>();

		int index = 0;
		Iterator<Product> it = products.iterator();

		while (it.hasNext()) {
			if (it.next() instanceof TV) {
				tv.add((TV) products.get(index));
			}
			index++;
		}
		return tv;
	}

	List<Refrigerator> printRef() {

		System.out.println();
		System.out.println("=============================냉장고=============================");

		List<Refrigerator> ref = new ArrayList<>();

		int index = 0;
		Iterator<Product> it = products.iterator();

		while (it.hasNext()) {
			if (it.next() instanceof Refrigerator) {
				ref.add((Refrigerator) products.get(index));
			}
			index++;
		}
		return ref;
	}

	List<Product> delPro(int isbn) {
		System.out.println();
		System.out.println("=============================상품 삭제 (isbn)=============================");

		int index = 0;
		Iterator<Product> it = products.iterator();

		while (it.hasNext()) {
			if (it.next().getIsbn() == isbn) {
				products.remove(index);
			}
			index++;
		}
		return products;
	}

	Product update(int isbn, int price) {
		System.out.println();
		System.out.println("=============================상품 가격 변경=============================");

		int index = 0;

		Iterator<Product> it = products.iterator();

		while (it.hasNext()) {
			if (it.next().getIsbn() == (isbn)) {
				products.get(index).setPrice(price);
				return products.get(index);
			}
			index++;
		}
		return null;
	}

	List<Refrigerator> ref400() {
		System.out.println();
		System.out.println("=============================400리터 이상 냉장고=============================");

		List<Refrigerator> refs = new ArrayList<>();
		List<Refrigerator> refs400 = new ArrayList<>();

		Iterator<Product> it = products.iterator();

		int index = 0;

		while (it.hasNext()) {
			if (it.next() instanceof Refrigerator) {
				refs.add((Refrigerator) products.get(index));
			}
			index++;
		}
		Iterator<Refrigerator> itr = refs.iterator();

		index = 0;
		while (itr.hasNext()) {
			if (itr.next().getLitter() <= refs.get(index).getLitter()) {
				refs400.add(refs.get(index));
			}
			index++;
		}

		return refs400;
	}

	List<TV> TV50() {
		System.out.println();
		System.out.println("=============================50인치 이상 TV=============================");

		List<TV> refs = new ArrayList<>();
		List<TV> refs400 = new ArrayList<>();

		Iterator<Product> it = products.iterator();

		int index = 0;

		while (it.hasNext()) {
			if (it.next() instanceof TV) {
				refs.add((TV) products.get(index));
			}
			index++;
		}
		Iterator<TV> itr = refs.iterator();
		
		index = 0;

		while (itr.hasNext()) {
			if (itr.next().getInch() <= refs.get(index).getInch()) {
				refs400.add(refs.get(index));
			}
			index++;
		}

		return refs400;
	}

}
