package com.ssafy;

public class ProductTest {
public static void main(String[] args) {
	ProductMgrImpl mgr = new ProductMgrImpl();
	
	mgr.add(new TV(12345, "LG", 200, 3, 50));
	mgr.add(new TV(32165, "samsung", 220, 5, 40));
	mgr.add(new Refrigerator(65456, "LG", 230, 5, 500));
	mgr.add(new Refrigerator(78989, "samsung", 200, 2, 380));
	
	System.out.println(mgr.search());
	System.out.println(mgr.search(12345));
	System.out.println(mgr.searchPro("LG"));
	System.out.println(mgr.printRef());
	System.out.println(mgr.printTV());
	System.out.println(mgr.ref400());
	System.out.println(mgr.TV50());
	System.out.println(mgr.update(32165, 210));
	System.out.println(mgr.search());

	
}
}
