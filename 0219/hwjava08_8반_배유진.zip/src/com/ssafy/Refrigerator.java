package com.ssafy;

public class Refrigerator extends Product {
	
	@Override
	public String toString() {
		return super.toString()+"litter=" + litter + "\n";
	}


	int litter;
	
	
	public Refrigerator(int isbn, String name, int price, int amount, int litter) {
		super(isbn, name, price, amount);
		this.litter = litter;
		
	}


	public int getLitter() {
		return litter;
	}


	public void setLitter(int litter) {
		this.litter = litter;
	}


	

}
