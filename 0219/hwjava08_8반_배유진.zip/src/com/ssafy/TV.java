package com.ssafy;

public class TV extends Product {

	@Override
	public String toString() {
		return super.toString() + "inch=" + inch + "\n";
	}

	int inch;
	
	public TV(int isbn, String name, int price, int amount, int inch) {
		super(isbn, name, price, amount);
		this.inch = inch;
	}

	public int getInch() {
		return inch;
	}

	public void setInch(int inch) {
		this.inch = inch;
	}



}
