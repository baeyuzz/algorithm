package com.ssafy;

public interface IProductMgr {

}
