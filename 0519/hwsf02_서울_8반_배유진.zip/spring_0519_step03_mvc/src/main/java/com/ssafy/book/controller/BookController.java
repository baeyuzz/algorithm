package com.ssafy.book.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.ssafy.book.dto.Book;
import com.ssafy.book.service.BookService;

@Controller
public class BookController {

	private BookService bookService;

	@Autowired
	public void setBookService(BookService bookService) {
		this.bookService = bookService;
	}

	// 도서목록 요청처리

	@RequestMapping(value = "/listBook.do", method = RequestMethod.GET)
	public ModelAndView getList() {
		// 도서목록 조회
		List<Book> bookList = bookService.searchAll();
		ModelAndView mav = new ModelAndView();
		mav.addObject("list", bookList);
		mav.setViewName("listBook");
		return mav;
	}

	// 도서등록 요청처리
	@RequestMapping("/insertBookForm.do")
	public ModelAndView insertPage() {
		ModelAndView mav = new ModelAndView();
		mav.setViewName("insertBook");
		return mav;
	}

	@RequestMapping("/insertBook.do")
	public ModelAndView registerBook(Book book) {

		bookService.insert(book);

		// 목록 컨트롤러로 리다이렉트
		// 리다이렉트일 경우 컨텍스트 패스는 알아서 스프링이 넣어준다.
		ModelAndView mav = new ModelAndView();
		mav.setViewName("redirect:/listBook.do");
		return mav;
	}

	@RequestMapping(value = "/searchBook.do", method = RequestMethod.GET)
	public ModelAndView searchBook(String isbn) {
		Book book = bookService.search(isbn);
		ModelAndView mav = new ModelAndView();
		mav.addObject("book", book);
		mav.setViewName("detailBook");
		return mav;

	}

}
