package network;

import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;

public class NetworkSimpleServer {
	public static void main(String[] args) {
		int port = 5088;

		try (ServerSocket serverSocket = new ServerSocket(port)) { // finally 에서 자원 정리 따로 안 해도 됨 auto closed?? 머시기임
			System.out.println("network simple server started");

			while (true) {
				Socket socket = serverSocket.accept(); // 계속 4101 모니터링 함
				// 이후 연결 되면 작업 시작
				OutputStream output = socket.getOutputStream();
				PrintWriter writer = new PrintWriter(output, true);
				writer.println("hello");
			}
		} catch (IOException e) {
			System.out.println("network simple server exception : " + e.getMessage());
			e.printStackTrace();

		}
	}
}
