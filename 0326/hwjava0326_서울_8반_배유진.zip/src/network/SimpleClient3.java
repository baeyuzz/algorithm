package network;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Scanner;

//Client
/**
 * 1. Socket(IP address, Port) 생성 2. Socket으로부터 입출력 스트림 얻어냄 3. 스트림으로 메세지 전송 4.
 * Socket 닫기(close()) 5. 스트림 닫기
 */
public class SimpleClient3 {
	public static void main(String[] args) throws Exception {

		BufferedReader sin = new BufferedReader(new InputStreamReader(System.in));

		Socket client;
		InputStream in;
		DataInputStream dis;
		DataOutputStream dos;

		client = new Socket("127.0.0.1", 8888);
		in = client.getInputStream();
		dis = new DataInputStream(in);
		dos = new DataOutputStream(client.getOutputStream());

		System.out.println("client");

		String str = null;

		while ((str = sin.readLine()) != null) { // 표준 입력 읽어서 서버로 전송
			dos.writeUTF(str);
			dos.flush();

			if (str.equals("Q")) {
				dos.writeUTF(str);
				break;
			}
			System.out.println("서버에서 온 메세지 : " + dis.readUTF());
		}

		dis.close();
		in.close();

		dos.close();

		client.close();

	}
}
