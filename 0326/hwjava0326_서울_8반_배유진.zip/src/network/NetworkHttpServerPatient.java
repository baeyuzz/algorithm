package network;

import java.io.BufferedWriter;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;

import medical.Hospital;
import person.Patient;
import person.Person;

public class NetworkHttpServerPatient {
	public static void main(String[] args) {

		Patient p1 = new Patient("전정국", 24, "010-9797-0901", "고열", "901", true);
		Patient p2 = new Patient("김청하", 25, "010-1996-0209", "기침", "001", false);

		// hospital collection
		List<Patient> pList = new ArrayList<Patient>();
		pList.add(p1);
		pList.add(p2);
		StringBuilder sb = new StringBuilder();
		
		
		sb.append("<html><body><h2>환자</h2><table style = 'border: 1px solid green;'>");
		for (Patient h : pList) {
			sb.append("<tr style = 'border : 1px solid green;'><td>").
			append(h.getName()).append("</td><td>")
					.append(String.valueOf(h.getPhone())).append("</td></tr>");
		}

		sb.append("</table></body></html>");

		String html = sb.toString();
		System.out.println(html);

		try (ServerSocket ss = new ServerSocket(8090)) {
			while (true) {
				try (Socket s = ss.accept()) {
					BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(s.getOutputStream(), "UTF-8"));

					bw.write("HTTP/1.1 200 OK\r\n");
					bw.write("Content-Type : text/html;charset=utf-8\r\n");
					bw.write("Content-Length : " + html.length() + "\r\n");
					bw.write("\r\n");
					bw.write(html);
					bw.write("\r\n");
					bw.flush();

				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}