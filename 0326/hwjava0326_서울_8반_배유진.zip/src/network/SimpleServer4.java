package network;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;

public class SimpleServer4 {
	public static void main(String[] args) throws IOException {
		
		ServerSocket server;
		OutputStream out;
		DataOutputStream dos;
		DataInputStream dis;
		
		server = new ServerSocket(8888);
		
		while(true) {
			Socket client;
			System.out.println("server : waiting client");
			
			client = server.accept();
			System.out.println("server : conneted client");
			
			
			new Thread() {
				public void run() {
					OutputStream out;
					DataOutputStream dos;
					DataInputStream dis;
					
					try {
						out = client.getOutputStream();
						dos = new DataOutputStream(out);
						dis = new DataInputStream(client.getInputStream());
						String str = null;
						while(!(str = dis.readUTF()).equals("Q")) {
							System.out.println(str);
							dos.writeUTF(str);
							dos.flush();
						}
						dos.close();
						dis.close();
						out.close();
					}catch (Exception e) {
						// TODO: handle exception
					}
				};
			}.start();
			
		}

}

}
