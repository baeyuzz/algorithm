package network;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Scanner;

//Client
/**
 * 1. Socket(IP address, Port) 생성 2. Socket으로부터 입출력 스트림 얻어냄 3. 스트림으로 메세지 전송 4.
 * Socket 닫기(close()) 5. 스트림 닫기
 */
public class SimpleClient2 {
	public static void main(String[] args) throws Exception {

		Socket client;
		InputStream in;
		DataInputStream dis;

		client = new Socket("127.0.0.1", 8888);

		in = client.getInputStream();

		dis = new DataInputStream(in);

		String msg = dis.readUTF();

		System.out.println("msg from server : " + msg);

		// sending any msg to server
		
		Thread.sleep(10000);
		
		DataOutputStream dos = new DataOutputStream(client.getOutputStream());
		
		
		dos.writeUTF("I'm client2");

		dis.close();
		in.close();
		
		dos.close();
		
		client.close();

	}
}
