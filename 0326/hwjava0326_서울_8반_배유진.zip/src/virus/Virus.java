package virus;

public class Virus {
	private int level;
	private String name;

	public int getLevel() {
		return level;
	}

	public void setLevel(int level) {
		this.level = level;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Virus(String name, int level) {
		super();
		this.level = level;
		this.name = name;
	}

	public Virus() {

	}

	public Virus(int level, String name) {
		super();
		this.level = level;
		this.name = name;
	}

}
