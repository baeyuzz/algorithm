package virus;

public class CoronaThreadSync extends Thread {

	Cell cell;

	public CoronaThreadSync(Cell cell) {
		this.cell = cell;
	}

	@Override
	public void run() {
		synchronized (cell) {
			if (cell.power >= 100) {
				try {
					Thread.sleep(500);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
				cell.power -= 100;
			}

			if (cell.power < 100) {
				try {
					cell.wait(); // 100 보다 작은 애들은 wait하게 한 후에 적혈구가 power 채우면 얘네 다 깨워줌
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
		}
		System.out.println(cell.power);
	}

}
