package xml;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class SongDomTest {
	public static void main(String[] args) {
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		// singleton pattern 이라서 new 하지 않음
		try {
			DocumentBuilder builder = factory.newDocumentBuilder();;
			Document doc = builder.parse("./src/xml/song.xml");
			Element root = doc.getDocumentElement();
			System.out.println(root.getNodeName()); // songs 출력
			
//			NodeList list = root.getElementsByTagName("title");
//			for (int i = 0; i < list.getLength(); i++) {
//				Node node = list.item(i);
////				System.out.println(node.getFirstChild().getNodeValue());
//				System.out.println(node.getTextContent()); // 위에 거랑 똑같음
//			}
			
			NodeList list = root.getElementsByTagName("song");
			for (int i = 0; i < list.getLength(); i++) {
				Element song = (Element) list.item(i); // song - 안에 여러 tags 있음
				NodeList title
				= song.getElementsByTagName("title");
				System.out.println(title.item(0).getTextContent());
			}
			
			
		} catch (Exception e) {
			e.printStackTrace();
			// TODO: handle exception
		}
	}
}

// DOM : xml 문서 전체를 객체의 트리 형태로 메모리에 가짐
//		 node CRUD available, 노드 조작 가능