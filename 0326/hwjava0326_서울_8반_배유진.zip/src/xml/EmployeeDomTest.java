package xml;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class EmployeeDomTest {
	public static void main(String[] args) {
//		File file = new File("./xml/emplyees.xml");
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		DocumentBuilder builder;


		try {
			builder = factory.newDocumentBuilder();
			Document doc = builder.parse("./src/xml/employees.xml");
			doc.getDocumentElement().normalize();
			Element root = doc.getDocumentElement();
			System.out.println("root : " + root.getNodeName());

			NodeList list = doc.getElementsByTagName("Employee");

			List<Employee> emplist = new ArrayList<Employee>();

			for (int i = 0; i < list.getLength(); i++) {
				Node node = list.item(i);

				if (node.getNodeType() == Node.ELEMENT_NODE) {
					Element element = (Element) node;

					String id = element.getAttribute("id");
					String name = element.getElementsByTagName("name").item(0).getTextContent();
					String age = element.getElementsByTagName("age").item(0).getTextContent();
					String gender = element.getElementsByTagName("gender").item(0).getTextContent();
					String role = element.getElementsByTagName("role").item(0).getTextContent();

					Employee emp = new Employee();
					emp.setId(Integer.parseInt(id));
					emp.setName(name);
					emp.setAge(Integer.parseInt(age));
					emp.setGender(gender);
					emp.setRole(role);

					emplist.add(emp);

				}

			}

			for (Employee emp : emplist) {
				System.out.println(emp);
			}

		}catch (Exception e) {
			e.printStackTrace();
			

		}
	}
}
