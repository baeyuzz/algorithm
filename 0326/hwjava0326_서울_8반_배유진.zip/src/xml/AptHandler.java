package xml;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class AptHandler {
	public static void main(String[] args) {
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		DocumentBuilder builder;

//		아파트 , 법정동, 거래 금액

		try {
			builder = factory.newDocumentBuilder();
			Document doc = builder.parse("./src/xml/AptDealHistory.xml");

			doc.getDocumentElement().normalize();
			NodeList list = doc.getElementsByTagName("item");
//			System.out.println(list.item(0));
//			System.out.println(list.getLength());
			for (int i = 0; i < list.getLength(); i++) {
				Node node = list.item(i);

				if (node.getNodeType() == Node.ELEMENT_NODE) {
					Element e = (Element) node;

					String apt = e.getElementsByTagName("아파트").item(0).getTextContent();
					String dong = e.getElementsByTagName("법정동").item(0).getTextContent();
					String cost = e.getElementsByTagName("거래금액").item(0).getTextContent();

					System.out.println("아파트 : " + apt + "\n법정동 :" + dong + "\n거래 금액  :" + cost);
					System.out.println("-----------------------------------------");
				}

			}

		} catch (Exception e) {
			e.printStackTrace();
			// TODO: handle exception
		}
	}
}
