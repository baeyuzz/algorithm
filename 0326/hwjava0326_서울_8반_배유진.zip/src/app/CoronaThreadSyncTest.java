package app;

import virus.Cell;
import virus.CoronaThreadSync;
import virus.RedBloodThread;

public class CoronaThreadSyncTest {
	public static void main(String[] args) {
		Cell cell = new Cell();
		
		for (int i = 0; i < 10; i++) {
			CoronaThreadSync t = new CoronaThreadSync(cell);
			t.start();
			
		}
		
		for (int i = 0; i < 10; i++) {
			RedBloodThread t = new RedBloodThread(cell);
			t.start();
			
		}
		
		try {
			Thread.sleep(500);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("cell power is " + cell.power);
	}
}

// wait : notify me later when ready
// notify : did something wake up one wait thread
// notifyAll : did something wake up all wait thread