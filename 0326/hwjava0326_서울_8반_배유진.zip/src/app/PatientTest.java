package app;

import person.PatientCareAction;

public class PatientTest {

	public static void main(String[] args) {
		// anonymous
		PatientCareAction helper = new PatientCareAction() {
			
			@Override
			public void whatIsYourName() {
				System.out.println("patient");
			}
		};
		helper.whatIsYourName();
		
		
		// lambda
		PatientCareAction helper2 = () -> System.out.println("patient");
		helper2.whatIsYourName();
	}
}
