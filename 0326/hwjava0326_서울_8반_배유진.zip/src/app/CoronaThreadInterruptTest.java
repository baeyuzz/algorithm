package app;

import virus.CoronaThread;

public class CoronaThreadInterruptTest {

	public static void main(String[] args) {
		CoronaThread t = new CoronaThread(2020);
		t.start();
		t.interrupt();

		try {
			Thread.sleep(300); // main thread 재움
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("main thread end");
	}

}
