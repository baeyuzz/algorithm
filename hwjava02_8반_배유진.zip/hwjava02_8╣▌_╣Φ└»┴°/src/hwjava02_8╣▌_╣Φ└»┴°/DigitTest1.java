package hwjava02_8반_배유진;

import java.util.Scanner;
// import java.util.Stack;

public class DigitTest1 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int[] ten = new int[11];
		
		while(true) {
			int n = sc.nextInt();
			if(n == 0)
				break;
			
			ten[(n/10)] ++;
			
		}
		
		for (int i = 0; i < 10; i++) {
			if (ten[i] != 0) {
				System.out.println(i + " : " + ten[i] + "개");
			}
		}
		
		
		
		/*
		Stack<Integer> num = new Stack<>();

		int n = 0;
		while (true) {
			n = sc.nextInt();
			num.push(n);
			if (num.contains(0))
				break;
		}

		num.pop();
		int size = num.size();

		int ten[] = new int[11];
		for (int i = 0; i < size; i++) {
			int tmp = num.pop();
			ten[(tmp / 10)]++;
		}

		for (int i = 0; i < 10; i++) {
			if (ten[i] != 0) {
				System.out.println(i + " : " + ten[i] + "개");
			}
		}
		*/
		sc.close();
	}
}
