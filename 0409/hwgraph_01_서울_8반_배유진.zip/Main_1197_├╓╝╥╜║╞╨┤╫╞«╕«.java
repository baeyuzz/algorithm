package algo;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.StringTokenizer;

class Edge implements Comparable<Edge> {

	int v1;
	int v2;
	int weight;

	Edge(int v1, int v2, int weight) {

		this.v1 = v1;
		this.v2 = v2;
		this.weight = weight;
	}

	@Override
	public int compareTo(Edge o) {

		return (this.weight > o.weight ? 1 : (this.weight == o.weight ? 0 : -1));
	}
}

public class Main_1197_최소스패닝트리 {

	static int[] parents;
	static int[] rank;
	static int result, unionCnt;

	public static void main(String[] args) throws IOException {

		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

		StringTokenizer st = new StringTokenizer(br.readLine(), " ");

		int v = Integer.parseInt(st.nextToken());
		int e = Integer.parseInt(st.nextToken());

		parents = new int[v + 1];
		Arrays.fill(parents, -1);
		ArrayList<Edge> es = new ArrayList<Edge>();

		int v1[] = new int[v];
		int v2[] = new int[v];
		int w[] = new int[e];

		for (int i = 0; i < v; i++) {
			st = new StringTokenizer(br.readLine(), " ");
			es.add(new Edge(Integer.parseInt(st.nextToken()), Integer.parseInt(st.nextToken()),
					Integer.parseInt(st.nextToken())));

		}

		Collections.sort(es);

		for (Edge edge : es) {
			if (union(edge.v1, edge.v2)) {
				unionCnt++;
				result += edge.weight;
			}
			if (unionCnt == e - 1)
				break;
		}

		System.out.println(Math.round(result));
	}

//	static void makeSet(int x) {
//		parents[x] = x;
//	}

	static int findSet(int x) {
		if (x == parents[x])
			return x;
		else {
			parents[x] = findSet(parents[x]);
			return parents[x];
		}
	}

	static boolean union(int a, int b) {
		int aRoot = find(a);
		int bRoot = find(b);
		if (aRoot != bRoot) {
			parents[bRoot] = aRoot;
			return true;
		}
		return false;
	}

	static int find(int a) {
		if (parents[a] < 0)
			return a;
		return parents[a] = find(parents[a]);
	}

}
