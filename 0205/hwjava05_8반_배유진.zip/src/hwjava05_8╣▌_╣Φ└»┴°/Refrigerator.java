package hwjava05_8반_배유진;

public class Refrigerator {
	private int isbn;
	private String product;
	private int price;
	private int amount;
	private double litter;

	public Refrigerator(int isbn, String product, int price, int amount, double litter) {
		super();
		this.isbn = isbn;
		this.product = product;
		this.price = price;
		this.amount = amount;
		this.litter = litter;
	}

	public int getIsbn() {
		return isbn;
	}

	public void setIsbn(int isbn) {
		this.isbn = isbn;
	}

	public String getProduct() {
		return product;
	}

	public void setProduct(String product) {
		this.product = product;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public int getAmount() {
		return amount;
	}

	public void setAmount(int amount) {
		this.amount = amount;
	}

	public double getLitter() {
		return litter;
	}

	public void setLitter(double litter) {
		this.litter = litter;
	}

	@Override
	public String toString() {
		return "Refrigerator [isbn=" + isbn + ", product=" + product + ", price=" + price + ", amount=" + amount
				+ ", litter=" + litter + "]";
	}

}
