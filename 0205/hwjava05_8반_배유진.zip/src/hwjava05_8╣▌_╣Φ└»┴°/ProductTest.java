package hwjava05_8반_배유진;

public class ProductTest {
	public static void main(String[] args) {
		TV tv = new TV(123456, "benq27", 200000, 3, 27, "hd");
		System.out.println(tv.toString());
		Refrigerator r = new Refrigerator(4568735, "DIOS", 2000000, 1, 250);
		System.out.println(r.toString());
		
		System.out.println(tv.getProduct());
	}
}
