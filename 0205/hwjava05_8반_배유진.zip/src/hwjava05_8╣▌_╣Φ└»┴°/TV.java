package hwjava05_8반_배유진;

public class TV {
	private int isbn;
	private String product;
	private int price;
	private int amount;
	private double inch;
	private String display_type;
	
	public TV(int isbn, String product, int price, int amount, double inch, String display_type) {
		super();
		this.isbn = isbn;
		this.product = product;
		this.price = price;
		this.amount = amount;
		this.inch = inch;
		this.display_type = display_type;
	}

	public int getIsbn() {
		return isbn;
	}

	public void setIsbn(int isbn) {
		this.isbn = isbn;
	}

	public String getProduct() {
		return product;
	}

	public void setProduct(String product) {
		this.product = product;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public int getAmount() {
		return amount;
	}

	public void setAmount(int amount) {
		this.amount = amount;
	}

	public double getInch() {
		return inch;
	}

	public void setInch(double inch) {
		this.inch = inch;
	}

	public String getDisplay_type() {
		return display_type;
	}

	public void setDisplay_type(String display_type) {
		this.display_type = display_type;
	}

	@Override
	public String toString() {
		return "TV [isbn=" + isbn + ", product=" + product + ", price=" + price + ", amount=" + amount + ", inch="
				+ inch + ", display_type=" + display_type + "]";
	}

	
	
}
