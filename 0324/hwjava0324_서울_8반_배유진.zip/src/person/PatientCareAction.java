package person;

@FunctionalInterface
public interface PatientCareAction {
	void whatIsYourName(); // 1 abstract method

	default void whatIsYourCountry() {
		System.out.println("Korea");
	}
}
