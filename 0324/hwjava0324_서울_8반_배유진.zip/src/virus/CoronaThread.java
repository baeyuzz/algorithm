package virus;

public class CoronaThread extends Thread {
	int num;

	public CoronaThread() {

	}

	public CoronaThread(int num) {
		this.num = num;

	}

	@Override
	public void run() {

		try {
			System.out.println("thread try start");
			Thread.sleep(5000);
			System.out.println("thread try end");
		} catch (InterruptedException e) {
			System.out.println("thread interruped raised");
		}

		
		System.out.println(num);
	}

	public static void main(String[] args) {
		for (int i = 0; i < 1000; i++) {
			CoronaThread ct = new CoronaThread(i);
			ct.start();
		}
	}
}
