package app;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import medical.CDC;
import medical.Organization;
import medical.Hospital;
import medical.NotCoronaException;
import person.Patient;

public class MainTest {

	public static void main(String[] args) {
		Hospital univHospital = new Hospital("대학병원", 15, "001", 50, 10);
		Hospital localHospital = new Hospital("동네병원", 3, "901", 10, 2);

		Patient p1 = new Patient("환자1", 42, "010-1111-2222", "호흡곤란", "001", true);
		Patient p2 = new Patient("환자2", 30, "010-2222-2222", "과음", "901", false);

		List<Hospital> hospitalList = new ArrayList<Hospital>();
		hospitalList.add(univHospital);
		hospitalList.add(localHospital);

		Set<Patient> patientList = new HashSet<Patient>();
		patientList.add(p1);
		patientList.add(p2);

		Organization org = new CDC("질병관리본부", 200, hospitalList, patientList);

		org.about();

		CDC cdc = new CDC("질병관리본부", 200, hospitalList, patientList);

		Patient p3 = new Patient("환자3", 33, "010-3333-3333", "고열", "001", true);
		Patient p4 = new Patient("환자3", 33, "010-3333-3333", "고열", "001", true);

		// C:\Users\seow0\Desktop\ssafy

		try {
			univHospital.addPatient(cdc, p3);
			univHospital.addPatient(cdc, p4); // add p4

		} catch (NotCoronaException e) {
			// TODO Auto-generated catch block
			System.out.println("코로나 환자가 아닙니다");
//			e.printStackTrace();
		}

		System.out.println();
		System.out.println(cdc.getPatientList());

//		C:\Users\seow0\Desktop\ssafy
		String filePath = "c:" + File.separator + "Users" + File.separator + "seow0" + File.separator
				+ "Desktop" + File.separator + "ssafy";
//		String filePath = "c:" + File.separator + "ssafy";
		String fileName = "CoronaPatientList.csv";

		BufferedWriter writer = null;
//		try {
//			writer = new BufferedWriter(
//					new OutputStreamWriter(new FileOutputStream(filePath + File.separator + fileName), "MS949"));
//
//			for (Patient p : patientList) {
//				writer.write(p.getName() + "," + p.getAge() + "," + p.getPhone());
//				writer.newLine();
//			}
//		} catch (Exception e) {
//			e.printStackTrace();
//		} finally {
//			if (writer != null) {
//				try {
//					writer.flush();
//				} catch (IOException e) {
//					// TODO Auto-generated catch block
//					e.printStackTrace();
//				}
//				try {
//					writer.close();
//				} catch (IOException e) {
//					// TODO Auto-generated catch block
//					e.printStackTrace();
//				}
//			}
//		}

	}

}
