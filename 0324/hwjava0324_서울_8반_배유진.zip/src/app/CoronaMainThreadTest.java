package app;

import virus.CoronaRunnable;

public class CoronaMainThreadTest {

	public static void main(String[] args) {
		CoronaRunnable cr = new CoronaRunnable(2020);
		Thread t = new Thread(cr);
		t.start();
		
		
		try {
			Thread.sleep(8000); // 내가 자고 싶으면 자는 거임 개별적임
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

//		try {
//			t.join(); // 이 스레드 끝날 때까지 대기하다가 그 뒤에 실행됨, 간섭함 
//		} catch (InterruptedException e) {
//			e.printStackTrace();
//		}

		System.out.println("main thread end"); // t가 끝나야 이게 실행됨
	}
}

/*
 * 내가 슬립해도 다른 애가 방해해서 깨어날 수 있음 깨어나면 다른 스레드들과 경쟁한(runnable) 후 running 가능
 * 
 * 
 * run()을 직접 부르면 run()을 호출하는 스레드가 직접 실행하고, start()를 호출하면 job스케쥴러에 등록되어 새로운 쓰레드가
 * 생성되어 실행합니다.
 * 
 * yield() 실행 양보 runnable 상태로 이동됨
 * 
 */
