package com.ssafy.book.service;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ssafy.book.dao.BookDao;
import com.ssafy.book.dto.Book;
import com.ssafy.book.dto.UserInfo;

@Service
public class BookServiceImpl implements BookService {

	private BookDao dao;

	@Autowired
	public void setDao(BookDao dao) {
		this.dao = dao;
	}

	public List<Book> searchAll() {
		return dao.searchAll();
	}

	public Book search(String isbn) {
		return dao.search(isbn);
	}

	public void insert(Book book) {
		dao.insert(book);
	}

	public void update(Book book) {
		dao.update(book);
	}

	public void delete(String isbn) {
		dao.delete(isbn);
	}

	@Override
	public List<Book> searchByCondition(Map<String, Object> condition) {
		return dao.searchByCondition(condition);
	}

	@Override
	public boolean login(UserInfo user) {
		return (dao.login(user) != null);
	}

	@Override
	public UserInfo mypage(String userId) {
		return dao.mypage(userId);
	}

	@Override
	public void updateMyPage(UserInfo user) {
		dao.updateMyPage(user);
	}
}
