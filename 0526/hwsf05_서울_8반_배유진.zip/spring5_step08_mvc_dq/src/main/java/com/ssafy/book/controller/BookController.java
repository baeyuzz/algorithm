package com.ssafy.book.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.ssafy.book.dto.Book;
import com.ssafy.book.service.BookService;


@RequestMapping("/book")
@Controller
public class BookController {

	private BookService bookService;
	
	@Autowired
	public void setBookService(BookService bookService) {
		this.bookService = bookService;
	}
	
	//도서목록 요청처리

//	@RequestMapping(value = "/listBook.do",method = RequestMethod.GET)
	@GetMapping("/list.do")
//	public ModelAndView  getList() {
//		// 도서목록 조회
//		List<Book> bookList = bookService.searchAll();
//		ModelAndView mav = new ModelAndView();
//		mav.addObject("list", bookList);
//		mav.setViewName("listBook"); // 접두사 생략시 forward
//		return mav;
//	}
	public String  getList(Model model) {
		// 도서목록 조회
		List<Book> bookList = bookService.searchAll();
		model.addAttribute("list", bookList);
		return "listBook";
	}
	
	
	//도서등록 요청처리
//	@RequestMapping(value = "/insertBook.do",method = RequestMethod.POST)
	@PostMapping("/insert.do")
	/*
	 * public ModelAndView register(Book book) { // 도서등록 bookService.insert(book);
	 * ModelAndView mav = new ModelAndView();
	 * mav.setViewName("redirect:/listBook.do"); return mav; }
	 */
	public String  register(Book book,HttpSession session) {
		// 도서등록
		bookService.insert(book);
		return "redirect:/book/list.do";
	}
	
//	@RequestMapping(value = "/insertBookForm.do",method = RequestMethod.GET)
	@GetMapping("/insertForm.do")
	/*
	 * public ModelAndView registerForm() { // 도서등록 ModelAndView mav = new
	 * ModelAndView(); mav.setViewName("insertBook"); return mav; }
	 */	
	public String  registerForm() {
		// 도서등록
		return "insertBook";
	}	
	
	@GetMapping("/detail.do")
	public String detailBook(String isbn,Model model) {
		model.addAttribute("book", bookService.search(isbn));
		return "detailBook";
	}
	@GetMapping("/remove.do")
	public String removeBook(String isbn) {
		bookService.delete(isbn);
		return "redirect:/book/list.do";
	}
	@GetMapping("/updateForm.do")
	public String updateFormBook(String isbn,Model model) {
		model.addAttribute("book", bookService.search(isbn));
		return "updateBook";
	}
	@PostMapping("/update.do")
	public String updateBook(Book book) {
		bookService.update(book);
		return "redirect:/book/list.do";
	}
	
	@PostMapping("/searchByCondition.do")
	public String searchByCondition(@RequestParam(name = "title") String t, String author, Model model) { // @requestparam 붙혀도 안붙혀도 됨 , 이름 서로 안 맞으면 저렇게,,
		Map<String, Object> map = new HashMap<String, Object>();
		if(t!=null && t.trim().length()!=0)
			map.put("title", t);
		if(author!=null && author.trim().length()!=0)
			map.put("author", author);

		model.addAttribute("list", bookService.searchByCondition(map));
		return "listBook";
	}
}
