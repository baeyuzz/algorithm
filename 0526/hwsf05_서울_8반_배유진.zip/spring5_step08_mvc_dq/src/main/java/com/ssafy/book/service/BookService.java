package com.ssafy.book.service;

import java.util.List;
import java.util.Map;

import com.ssafy.book.dto.Book;
import com.ssafy.book.dto.UserInfo;

public interface BookService {
	public List<Book>  searchAll();
	public Book search(String isbn);
	public void insert(Book book);
	public void update(Book book);
	public void delete(String isbn);
	public List<Book> searchByCondition (Map<String, Object> condition);
	
	public boolean login(UserInfo user);
	
	
	public UserInfo mypage(String userId);
	public void updateMyPage(UserInfo user);
}



