package com.ssafy.book.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.ssafy.book.dto.Book;
import com.ssafy.book.dto.UserInfo;
import com.ssafy.book.service.BookService;

@RequestMapping("/user")
@Controller
public class UserController {

	@Autowired
	private BookService service;

	@PostMapping("/login.do")
	public String login(UserInfo user, HttpSession session) {
		boolean res = service.login(user);

		if (res) {
			session.setAttribute("userId", user.getUserId());
			return "redirect:/book/list.do";
		} else
			return "redirect:/index.jsp";
	}

	@GetMapping("/logout.do")
	public String logout(HttpSession session) {
		session.invalidate();

		return "redirect:/index.jsp";
	}

	@GetMapping("/mypage.do")
	public String mypage(HttpSession session, Model model) {
		String id = (String) session.getAttribute("userId");
		model.addAttribute("user", service.mypage(id));
		return "mypage";
	}

	@GetMapping("/updateForm.do")
	public String updateForm(String id, Model model) {
		model.addAttribute("user", service.mypage(id));
		return "updateMyPage";
	}
	
	@PostMapping("/update.do")
	public String updateBook(UserInfo user) {
		service.updateMyPage(user);
		return "redirect:/user/mypage.do";
	}
}
