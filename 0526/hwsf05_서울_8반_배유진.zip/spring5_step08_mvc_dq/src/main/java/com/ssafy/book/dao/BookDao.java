package com.ssafy.book.dao;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

import com.ssafy.book.dto.Book;
import com.ssafy.book.dto.UserInfo;

@Mapper
@Repository
public interface BookDao {
	public List<Book>  searchAll();
	public Book  search(String isbn);
	public void insert(Book book);
	public void update(Book book);
	public void delete(String isbn);
	public List<Book> searchByCondition (Map<String, Object> condition);

	public String login(UserInfo user);

	public UserInfo mypage(String id);
	public void updateMyPage(UserInfo user);

}
