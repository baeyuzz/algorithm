package com.ssafy;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication // 환경설정, xml 대신하는 자바소스
public class Spring5Step07MvcBootApplication {

	public static void main(String[] args) {
		SpringApplication.run(Spring5Step07MvcBootApplication.class, args);
	}

}
