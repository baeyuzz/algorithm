package com.ssafy;

public class Refrigerator extends Product {
	
	public Refrigerator(int isbn, String name, int price, int amount) {
		super(isbn, name, price, amount);
	}
	

}
