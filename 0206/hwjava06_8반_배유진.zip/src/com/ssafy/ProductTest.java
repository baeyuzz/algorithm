package com.ssafy;

public class ProductTest {
	public static void main(String[] args) {

		ProductMgr mgr = new ProductMgr();
		mgr.inputdata();
		mgr.priceall();
		mgr.print();
		mgr.delPro();
		mgr.delPro();

		mgr.printTV();
		mgr.printRef();
		mgr.searchPro();
	}
	}
