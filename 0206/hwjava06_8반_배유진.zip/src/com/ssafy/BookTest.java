package com.ssafy;

import java.util.Scanner;

public class BookTest {
	public static void main(String[] args) {
		Book[] b = new Book[5];
		b[0] = new Magazine("12345", "android app", "hong", "abc.kr", 25000, "light weight frame", 2019, 6);
		b[1] = new Book("33351", "Servelt/JSP", "park", "jaen.kr", 41000, "model");
		b[2] = new Book("23414", "java pro", "kim", "naives", 15000, "java");
		b[3] = new Magazine("12355", "java ", "pine", "jaen.kr", 7000, "entertainment", 2018, 3);
		b[4] = new Book("25253", "jdbc pro", "lee", "out", 23000);

		System.out.println("***************************도서 목록***************************");

		for (Book book : b) {
			System.out.println(book.toString());
		}

		System.out.println();
		System.out.println("***************************isbn 검색***************************");
		Scanner sc = new Scanner(System.in);
		System.out.print("isbn 입력 : ");

		String tmp = sc.next();

		for (Book book : b) {
			if (book.getIsbn().equals(tmp))
				System.out.println(book.toString());
		}

		System.out.println();
		System.out.println("***************************title 검색***************************");

		System.out.print("title 입력 : ");
		sc.nextLine();
		tmp = sc.nextLine();
		for (Book book : b) {
			if (book.getTitle().contains(tmp))
				System.out.println(book.toString());
		}

		System.out.println();
		System.out.println("***************************Book 목록***************************");

		for (Book book : b) {
			if (!(book instanceof Magazine))
				System.out.println(book.toString());
		}
		
		System.out.println();
		System.out.println("***************************Magazine 목록***************************");

		for (Book book : b) {
			if (book instanceof Magazine)
				System.out.println(book.toString());
		}
		

		System.out.println();
		System.out.println("***************************publisher 검색***************************");

		System.out.print("출판사 입력 : ");
		tmp = sc.next();
		for (Book book : b) {
			if (book.getPublisher().equals(tmp))
				System.out.println(book.toString());
		}

		System.out.println();
		System.out.println("***************************가격 검색***************************");

		System.out.print("가격 입력 : ");
		int temp = sc.nextInt();
		for (Book book : b) {
			if (book.getPrice() <= temp)
				System.out.println(book.toString());
		}
		
		System.out.println();
		System.out.println("***************************전체 도서 금액**************************");

		temp = 0;
		for (Book book : b) {
			temp+=book.getPrice();
		}
		System.out.println(temp);

		System.out.println();
		System.out.println("***************************전체 도서 평균 금액**************************");

		System.out.println(temp/b.length);
		
	}

}
