package com.ssafy;

public class TV extends Product {

	public TV(int isbn, String name, int price, int amount) {
		super(isbn, name, price, amount);
	}

}
