package com.ssafy;

import java.util.Scanner;

public class ProductMgr {
	Product[] p = new Product[5];
	Scanner sc = new Scanner(System.in);

	void inputdata() {
		p[0] = new TV(12345, "benq", 1420000, 5);
		p[1] = new Refrigerator(13525, "dios", 2990000, 3);
		p[2] = new TV(32165, "LG1", 1380000, 6);
		p[3] = new TV(98765, "LG2", 2200000, 3);
		p[4] = new Refrigerator(65498, "dimsum", 890000, 6);
	}

	void print() {
		for (Product pro : p) {
			System.out.println(pro.toString());
		}

		System.out.println();
		System.out.println("=============================isbn 검색=============================");

		System.out.print("isbn 입력 : ");

		int tmp = sc.nextInt();

		for (Product pro : p) {
			if (pro.getIsbn() == tmp)
				System.out.println(pro.toString());
		}
	}

	void searchPro() {
		sc.nextLine();
		System.out.println();
		System.out.println("=============================상품명 검색=============================");
		System.out.print("상품명 입력 : ");
		String temp = sc.nextLine();

		for (Product pro : p) {
			if (pro.getName().contains(temp))
				System.out.println(pro.toString());
		}
	}

	void printTV() {
		System.out.println();
		System.out.println("=============================TV=============================");

		for (Product pro : p) {
			if (pro instanceof TV)
				System.out.println(pro.toString());
		}

	}

	void printRef() {

		System.out.println();
		System.out.println("=============================냉장고=============================");

		for (Product pro : p) {
			if (pro instanceof Refrigerator)
				System.out.println(pro.toString());
		}
	}

	void delPro() {
		System.out.println();
		System.out.println("=============================상품 삭제 (isbn)=============================");

		System.out.print("isbn 입력 : ");
		int tmp = sc.nextInt();

		int len = p.length-1;
		Product[] pro = new Product[len];
		
		int i = 0;
		
		for (int j = 0; j < len; j++) {
			if (tmp == p[i].getIsbn()) {
				i++;
				j--;
				continue;
			}
			pro[j] = p[i];
			i++;
		}
		for(Product pp : pro)
			System.out.println(pp.toString());

	}

	void priceall() {

		System.out.println();
		System.out.println("=============================전체 가격=============================");
		int tmp = 0;
		for (Product pro : p) {
			tmp += pro.getAmount() * pro.getPrice();
		}
		System.out.println(tmp);

	}
}
