package com.ssafy.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/product.do")
public class Product extends HttpServlet {
	private static final long serialVersionUID = 1L;

	private void process(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		request.setCharacterEncoding("utf-8");
		String productname = request.getParameter("productname");
		int price = Integer.parseInt(request.getParameter("price"));
		String description = request.getParameter("description");

		response.setContentType("text/html;charset=utf-8"); // 가져오기
		PrintWriter out = response.getWriter(); // 문자 단위면 getWriter, binary type은 getoutputstream
		out.println("<html>");
		out.println("<body>");
		out.println("<h1>입력한 정보</h1>");
		out.print("<h2>상품명 : " + productname + "</h2>");
		out.print("<h2>상품 가격 : " + price + "</h2>");
		out.print("<h2>상품 설명 : " + description + "</h2>");
		out.println("</body>");
		out.println("</html>");
		out.close();
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("utf-8"); // msg body(짐칸)에 적용
		process(request, response);
	}

}
