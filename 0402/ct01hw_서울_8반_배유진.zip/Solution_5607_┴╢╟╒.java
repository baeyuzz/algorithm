import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

/**
 * 구하려는 수 1234567891이 소수이기 때문에 페르마의 소정리를 이용해서 구할 수 있다. a와 m이 서로소일 때, a^(m-1)을
 * m으로 나눈 나머지는 1이다. 따라서 역원(=1234567891로 나눈 나머지)가 되기 위한 조건은 a^(m-2)이다.
 * 
 * @author student
 *
 */
public class Solution_5607_조합{
	static int n;
	static int r;
	static int d = 1234567891;

	public static void main(String[] args) throws NumberFormatException, IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

		int t = Integer.parseInt(br.readLine());

		for (int test = 1; test <= t; test++) {
			StringTokenizer st = new StringTokenizer(br.readLine());

			n = Integer.parseInt(st.nextToken());
			r = Integer.parseInt(st.nextToken());

			long facto[] = new long[n + 1];

			facto[0] = 1;
			for (int i = 1; i <= n; i++) {
				facto[i] = (i * facto[i - 1]) % d;
			}

			long pre = (facto[r] * facto[n - r]) % d;
			long res = calc(pre, d - 2);

			res = (facto[n] * res) % d;

			System.out.println("#" + test + " " + res);
		}
	}

	static long calc(long n, int x) {

		if (x == 0)
			return 1;
		long tmp = calc(n, x / 2);
		long res = (tmp * tmp) % d;
		if (x % 2 == 0)
			return res;
		else
			return (res * n) % d;

	}
}
