import Vue from 'vue';
import Vuex from 'vuex';
import Constant from './Constant.js';
import http from './http-common.js'

Vue.use(Vuex);

const store = new Vuex.Store({
    state : {
        todoItems : []  
    },
    actions :{
        [Constant.GET_TODOLIST] : (store) => {
            http.get('/todolist/user/java')
            .then(response => store.commit(Constant.GET_TODOLIST,{todoItems : response.data}))
            .catch(exp => alert('처리에 실패하였습니다.'+exp));
         
        },
        [Constant.CLEAR_TODO] : (store) => {
            http.delete('/todolist/user/'+'java')
            .then(()=>{
                alert('할일 목록을 삭제하였습니다.');
                store.commit(Constant.CLEAR_TODO,{todoItems:[]});
            })
            .catch(()=>alert('할일 목록 삭제에 실패하였습니다.'));
        },
        [Constant.COMPLETE_TODO] : (store, payload) => {
            http.put('/todolist/todo/done/'+payload.no)
            .then(()=> store.dispatch(Constant.GET_TODOLIST))
            .catch(exp => alert('처리에 실패하였습니다. : '+exp));
        },
        [Constant.REMOVE_TODO] : (store, payload) => {
            http.delete('/todolist/todo/'+payload.no)
            .then(()=>store.dispatch(Constant.GET_TODOLIST))
            .catch(exp => alert('처리에 실패하였습니다. : '+exp));
   
        },
        [Constant.ADD_TODO] : (store,payload) =>{
            if(payload.content.trim() != ''){
                console.log('할일 추가 :: '+payload.content.trim());
                http.post('/todolist/todo',{
                        content : payload.content,
                        endDate : payload.endDate,
                        userId: 'java'
                    })
                    .then(()=>store.dispatch(Constant.GET_TODOLIST))
                    .catch(()=> alert('추가에 실패하였습니다.'));
                    payload.clear();
            }else{
                console.log('공백입력.');
                this.clear();
            }    
        }


    },
    mutations :{
        [Constant.GET_TODOLIST] : (state,payload) => {
            state.todoItems = payload.todoItems;
        },
        [Constant.CLEAR_TODO] : (state,payload) => {
            state.todoItems = payload.todoItems;
        }
    }
});

export default store;