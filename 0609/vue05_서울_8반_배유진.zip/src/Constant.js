const obj = {
    GET_TODOLIST : 'getTodoList',
    ADD_TODO : 'addTodo',
    REMOVE_TODO : 'removeTodo',
    COMPLETE_TODO : 'completeTodo',
    CLEAR_TODO : 'clearTodo'
}
export default obj;