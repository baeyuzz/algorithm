<template>
    <div  class="clearAllContainer">
        <span class="clearAllBtn" @click="clearTodo">Clear All</span>
    </div>
</template>

<script>
import Constant from '../Constant';

export default {
    methods: {
        clearTodo() {
          this.$store.dispatch(Constant.CLEAR_TODO);
        }
    },
}
</script>

<style scoped>
.clearAllContainer {
    width: 8.5rem;
    height: 50px;
    line-height: 50px;
    background-color: white;
    border-radius: 5px;
    margin: 0 auto;
  }
  .clearAllBtn {
    color: #e20303;
		/* 추가 */
		display: block;
  }
</style>