<template>
  <div>
    <ul>
      <!-- <li v-for="todoItem in todoItems">{{todoItem}}</li> -->
      <!-- error v-bind:key='todoItem'추가해야함. -->
      <li v-for="(todoItem) in todoItems" v-bind:key="todoItem.no" class="shadow" 
              :class="{done: todoItem.done=='Y'}" @click="viewTodo(todoItem.no)">
        <i class="checkBtn fas fa-check" @click.stop="completeTodo(todoItem.no)" v-show="todoItem.done =='N'"></i>
        {{todoItem.content}} : {{todoItem.endDate}}
        <span
          class="removeBtn"
          type="button"
          @click="removeTodo(todoItem.no)"
        >
          <i class="far fa-trash-alt"></i>
        </span>
      </li>
    </ul>
  </div>
</template>

<script>
import Constant from "../Constant";
export default {
  computed: {
    todoItems(){
      return this.$store.state.todoItems;
    }
  },
  created() {
    this.getTodoList();
  },
  methods: {
    removeTodo(no) {
     this.$store.dispatch(Constant.REMOVE_TODO,{no});
    },
    getTodoList() {
      this.$store.dispatch(Constant.GET_TODOLIST);
    },
    completeTodo(no){
      this.$store.dispatch(Constant.COMPLETE_TODO, {no:no}); // no라는 이름으로 no넘겨줌 {no} 이렇게만 넘겨줘도됨
    }
  }
};
</script>

<style scoped>
ul {
  list-style-type: none;
  padding-left: 0px;
  margin-top: 0;
  text-align: left;
}
li {
  display: flex;
  min-height: 50px;
  height: 50px;
  line-height: 50px;
  margin: 0.5rem 0;
  padding: 0 0.9rem;
  background: white;
  border-radius: 5px;
}
.checkBtn {
  line-height: 45px;
  color: #62acde;
  margin-right: 5px;
}
.removeBtn {
  margin-left: auto;
  color: #de4343;
}

.list-item {
  display: inline-block;
  margin-right: 10px;
}
.list-move {
  transition: transform 1s;
}
.list-enter-active,
.list-leave-active {
  transition: all 1s;
}
.list-enter,
.list-leave-to {
  opacity: 0;
  transform: translateY(30px);
}
.done{
  background-color: lightslategray;
}
</style>