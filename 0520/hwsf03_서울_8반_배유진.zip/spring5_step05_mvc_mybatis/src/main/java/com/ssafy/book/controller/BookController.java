package com.ssafy.book.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.ssafy.book.dto.Book;
import com.ssafy.book.service.BookService;

@RequestMapping("/book")
@Controller
public class BookController {

	private BookService bookService;

	@Autowired
	public void setBookService(BookService bookService) {
		this.bookService = bookService;
	}

	// 도서목록 요청처리

	/*
	 * @RequestMapping(value = "/listBook.do",method = RequestMethod.GET) public
	 * ModelAndView getList() { // 도서목록 조회 List<Book> bookList =
	 * bookService.searchAll(); ModelAndView mav = new ModelAndView();
	 * mav.addObject("list", bookList); // request에 저장함.
	 * 
	 * mav.setViewName("listBook"); return mav; }
	 */

	@GetMapping("/list.do")
	public String getList(Model model) {
		List<Book> bookList = bookService.searchAll();
		model.addAttribute("list", bookList); // request에 저장함.

		return "listBook";
	}

	@PostMapping("/insert.do")
	public String register(Book book) {
		bookService.insert(book);
		return "redirect:/book/list.do";
	}
	@GetMapping("/insertForm.do")
	public String registerForm() {
		return "insertBook";
	}

	@GetMapping("search.do")
	public ModelAndView detailBook(String isbn) {
		Book b = bookService.search(isbn);
		ModelAndView mav = new ModelAndView();
		bookService.search(isbn);
		mav.addObject("book", b);
		mav.setViewName("detailBook");

		return mav;

	}

	@GetMapping("/updateBookForm.do")
	public String updateForm() {
		return "updateBook";
	}
	
	@PostMapping("/update.do")
	public String update(Book book) {
		bookService.update(book);
		return "redirect:/book/list.do";
	}

}
