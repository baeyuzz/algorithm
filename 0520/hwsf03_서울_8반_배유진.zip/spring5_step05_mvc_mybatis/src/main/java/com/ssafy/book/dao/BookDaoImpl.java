package com.ssafy.book.dao;
import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ssafy.book.dto.Book;

@Repository
public class BookDaoImpl implements BookDao {
	
	@Autowired
	private SqlSession sqlSession;
	
	public void insert(Book book){
		sqlSession.insert("book.insert", book);
	}
	public void update(Book book){
		sqlSession.update("book.update", book);
	}
	public void delete(String isbn){
		sqlSession.delete("book.delete",isbn);
	}
	public Book search(String isbn){
		return sqlSession.selectOne("book.search");
	}
	public List<Book> searchAll() {
		return sqlSession.selectList("book.searchAll");
	
	}

}





