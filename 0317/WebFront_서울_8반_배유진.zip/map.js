function MyMap() {
	this.map = new Object();
};

MyMap.prototype.put = function(key, val) {
	this.map[key] = val;
};

MyMap.prototype.get = function(key) {
	return this.map[key];
};

MyMap.prototype.size = function() {
	var cnt = 0;
	for ( var v in this.map) {
		cnt++;
	}
	return cnt;
};

MyMap.prototype.remove = function(key) {
	delete this.map[key];
};

MyMap.prototype.clear = function() {
	for ( var v in this.map) {
		delete this.map[v];
	}
};
